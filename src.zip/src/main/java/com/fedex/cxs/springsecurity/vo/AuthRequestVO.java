package com.fedex.cxs.springsecurity.vo;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.Data;
import lombok.ToString;


@Data
@ToString
public class AuthRequestVO implements Serializable{
	private String authCookie;
	private HttpServletRequest servletRequest;
	private HttpServletResponse servletResponse;
	
}
