package com.fedex.cxs.springsecurity.process;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.AuthenticationRealm;
import com.fedex.cxs.calc.security.ClientIdentity;
import com.fedex.cxs.calc.security.ConsumerIdentity;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.vo.PersonaType;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.util.AuthUtil;

public class ConsumerPayload implements Payload{

	
	private static final Logger Log = LoggerFactory
			.getLogger(ConsumerPayload.class);
	
	
	@Override
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication) {
		Map<String, String> fclHashMap = (Map<String, String>) CXSContextHolder.getContext().getProperty(AuthConstant.FCL_MAP);
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_REQUEST);
		RequestorIdentity requestorIdentity = new RequestorIdentity();
		Map<String, String> moreInfo = new HashMap<String, String>();
		ClientIdentity clientIdentity = new ClientIdentity();
		ConsumerIdentity consumerIdentity = new ConsumerIdentity();
		clientIdentity.setClientKey(authentication.getOAuth2Request().getClientId());
		//Identity creation for already log in user
		if (httpRequest != null && httpRequest.getCookies() != null) {
			for (Cookie c : httpRequest.getCookies()) {
				if (AuthConstant.FCL_LOGIN_COOKIE_NAME.equals(c.getName())) {
					Log.info("Setting payload for already logged in user");
					requestorIdentity.setPersonaType(PersonaType.Consumer);
					consumerIdentity.setRawIdentity(c.getValue());
					consumerIdentity.setLoggedIn(true);
					requestorIdentity.setAuthenticationRealm(AuthenticationRealm.FCL);
				}else if (AuthConstant.FCL_UUID_COOKIE_NAME.equals(c.getName())){
					consumerIdentity.setIdentity(c.getValue());
				}
			}
		}
		if(fclHashMap!=null) {//Identity creation for Consumer with username and password
			requestorIdentity.setPersonaType(PersonaType.Consumer);
			consumerIdentity.setIdentity(fclHashMap.get("uuid"));
			consumerIdentity.setRawIdentity(fclHashMap.get("fdx_login"));
			requestorIdentity.setAuthenticationRealm(AuthenticationRealm.FCL);
			consumerIdentity.setLoggedIn(true);
			moreInfo.put("UserName", authentication.getUserAuthentication().getName());
		}else {//Identity creation for consumer nonlogin user
			requestorIdentity.setPersonaType(PersonaType.Consumer);
			consumerIdentity.setLoggedIn(false);
			requestorIdentity.setAuthenticationRealm(AuthenticationRealm.NOT_AUTHENTICATED);
		}
		moreInfo.put(AuthConstant.TIMESTAMP, AuthUtil.getCurrentTime());
		moreInfo.put(AuthConstant.APPMODE, httpRequest.getHeader(AuthConstant.APPMODE));
		requestorIdentity.setClientIdentity(clientIdentity);
		requestorIdentity.setConsumerIdentity(consumerIdentity);
		requestorIdentity.setAdditionalIdentity(moreInfo);
		Log.debug("Consumer RequestorIdentity =>"+requestorIdentity );
		return requestorIdentity;
		
		
	}
	
	

}
