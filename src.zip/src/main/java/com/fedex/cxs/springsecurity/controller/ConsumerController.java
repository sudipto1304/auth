package com.fedex.cxs.springsecurity.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.io.IOException;
import java.util.Map;

import javax.security.auth.message.config.AuthConfig;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.WebUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.config.OauthResponseAdvice;
import com.fedex.cxs.springsecurity.exceptions.InvalidTokenException;
import com.fedex.cxs.springsecurity.service.ConsumerService;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.vo.LogoutInputVO;
import com.fedex.cxs.springsecurity.vo.LogoutOutputVO;

@RefreshScope
@RestController
@RequestMapping(value = "/token/action")
public class ConsumerController {
	
	private static final Logger Log = LoggerFactory
			.getLogger(ConsumerController.class);

	@Autowired
	private ConsumerService service;


	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public ResponseEntity<LogoutOutputVO> logOut(
			HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, LogoutInputVO request) throws  InvalidTokenException {
		Log.info("***Logut Service Call***");
		boolean isLogoutSuccess = service.logout(request.getAccessToken());
		if (isLogoutSuccess) {
			Log.info("Logout successful");	
			return new ResponseEntity<LogoutOutputVO>(new LogoutOutputVO(AuthConstant.SUCCESS), HttpStatus.OK);
		}else{
			Log.info("Logout failed");	
			throw new InvalidTokenException("");
		}
	}

}
