package com.fedex.cxs.springsecurity.service;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.calc.apig.client.transaction.GetAuthTokenTransaction;
import com.fedex.cxs.calc.apig.client.vo.OAuthToken;
import com.fedex.cxs.calc.common.rest.client.pojo.RESTURI;
import com.fedex.cxs.calc.config.CommonAppConfig;
import com.fedex.cxs.calc.exception.CALException;
import com.fedex.cxs.calc.rest.client.adapters.RESTResponseAdapter;
import com.fedex.cxs.calc.rest.client.builders.RESTURIBuilder;
import com.fedex.cxs.calc.rest.client.strategy.apig.APIGRestStrategy;
import com.fedex.cxs.calc.security.AuthenticationRealm;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.authn.AuthenticationProvider;
import com.fedex.cxs.calc.security.fcl.FclIdentityProvider;
import com.fedex.cxs.calc.transformation.util.ClientContextUtil;
import com.fedex.cxs.calc.util.OauthUtil;
import com.fedex.cxs.calc.v3.vo.ClientContextVO;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.transaction.USRCLoginTransaction;
import com.fedex.cxs.springsecurity.vo.LoginCookieOutputVO;
import com.fedex.cxs.springsecurity.vo.LoginInputVO;

@Service
@RefreshScope
public class ConsumerService1 {
	
	private OAuthToken oauthToken;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerService1.class);
	
	public boolean login(LoginInputVO input, HttpServletRequest httpRequest) throws CALException{
		ClientContextUtil clinetContextUtil = new ClientContextUtil();
		ClientContextVO clientContextVO = clinetContextUtil.getClientContextV3(httpRequest);
		clientContextVO.setClientId("WCDO");
		try{
			oauthToken = new GetAuthTokenTransaction(CommonAuthConfig.getInstance().getURIConfigProperties()).deriveAuthToken();
			oauthToken.setExpiresInMsec(210000);
			APIGRestStrategy restStrategy = new APIGRestStrategy();
			restStrategy.setOauthToken(oauthToken);
			restStrategy.setEndPointURIKey(USRCLoginTransaction.END_POINT_URI_KEY);
			restStrategy.setClientContextVO(clientContextVO);
			RequestorIdentity requestorIdentity = new RequestorIdentity();
			requestorIdentity.setAuthenticationRealm(AuthenticationRealm.NOT_AUTHENTICATED);
			USRCLoginTransaction transaction = new USRCLoginTransaction(input,clientContextVO, requestorIdentity);
			
			restStrategy.setRequestorIdentity(requestorIdentity);
			RESTResponseAdapter restResponseAdapter = restStrategy
					.execute(transaction);
			LoginCookieOutputVO response = (LoginCookieOutputVO)
					restResponseAdapter.getResponseData(LoginCookieOutputVO.class);
			if(response != null){
				return true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		//loginProcessing(response);
		return false;
	}
	
	public boolean logout(String accessToken){
		JSONObject body = OauthUtil.decryptToken(accessToken, CommonAuthConfig.getInstance().getOauthProperties().getSignKey());
		ObjectMapper mapper = new ObjectMapper();
		RequestorIdentity identity;
		try {
			identity = mapper.readValue(body.toString(),
					RequestorIdentity.class);
		}catch(Exception e){
			
		}
		return false;
	}
	
}
