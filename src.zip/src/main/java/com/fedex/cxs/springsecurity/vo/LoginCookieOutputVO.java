package com.fedex.cxs.springsecurity.vo;

public class LoginCookieOutputVO {

	String fclCookie;
	String nameCookie;
	String contactNameCookie;
	String uuidCookie;

	public String getFclCookie() {
		return fclCookie;
	}

	public void setFclCookie(String fclCookie) {
		this.fclCookie = fclCookie;
	}

	public String getNameCookie() {
		return nameCookie;
	}

	public void setNameCookie(String nameCookie) {
		this.nameCookie = nameCookie;
	}

	public String getContactNameCookie() {
		return contactNameCookie;
	}

	public void setContactNameCookie(String contactNameCookie) {
		this.contactNameCookie = contactNameCookie;
	}

	public String getUuidCookie() {
		return uuidCookie;
	}

	public void setUuidCookie(String uuidCookie) {
		this.uuidCookie = uuidCookie;
	}
}