package com.fedex.cxs.springsecurity.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.ClientRegistrationException;
import org.springframework.stereotype.Component;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.vo.CxsClientDetails;

@Component
public class CxsClientDetailsService implements ClientDetailsService{
	private static final Logger Log = LoggerFactory
			.getLogger(CxsClientDetailsService.class);
	
	
	@Autowired
	private BCryptPasswordEncoder encoder;

	@Override
	@Cacheable(value="ClientDetails", key="#clientId")
	public ClientDetails loadClientByClientId(String clientId) throws ClientRegistrationException {
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_REQUEST);
		CxsClientDetails clientDetails = new CxsClientDetails();
		clientDetails.setClientId(clientId);
		clientDetails.setClientSecret( encoder.encode(httpRequest.getParameter(AuthConstant.SECRET)));
		clientDetails.setAuthorizedGrantTypes(Arrays.asList( new String[] {AuthConstant.GRANT_TYPE_PASSWORD, AuthConstant.CLIENT_CREDENTIALS, AuthConstant.CSP_CREDENTIALS, AuthConstant.REFRESH_TOKEN, AuthConstant.LOGOUT_GRANT_TYPE, AuthConstant.B2C_CUSTOM} ));
		String scopes = StringUtils.isEmpty(httpRequest.getParameter(AuthConstant.SCOPE))?httpRequest.getParameter(AuthConstant.SCOPE_CAPS) : httpRequest.getParameter(AuthConstant.SCOPE);
		String[] requestScopes;
		if(StringUtils.isEmpty(scopes)){
			requestScopes =  new String[] {AuthConstant.SCOPE_CXS} ;
		}else{
			requestScopes = scopes.split(",");
		}
		List<String> scopeList = new ArrayList<String>(Arrays.asList( requestScopes ));
		if(CommonAuthConfig.getInstance().getOauthProperties().isEnableEncryption()) {
			scopeList.add(AuthConstant.SCOPE_SECURE);
		}
		clientDetails.setScope(scopeList);
		String grantType = httpRequest.getParameter(AuthConstant.GRANT_TYPE);
		Log.info("ClientDetails service for grant type::"+grantType);
		if(AuthConstant.CLIENT_CREDENTIALS.equals(grantType)){
			clientDetails.setAccessTokenValiditySeconds(CommonAuthConfig.getInstance().getOauthProperties().getDirectIntegratorTokenTimeout());
		}else if(AuthConstant.CSP_CREDENTIALS.equals(grantType)){
			clientDetails.setAccessTokenValiditySeconds(CommonAuthConfig.getInstance().getOauthProperties().getCompatibleProviderTokenTimeout());
		}else{
			clientDetails.setAccessTokenValiditySeconds(AuthConstant.ACCESS_TOKEN_VALID);
		}
		
		clientDetails.setRefreshTokenValiditySeconds(AuthConstant.REFRESH_TOKEN_VALID);
		return clientDetails;
	}


}
