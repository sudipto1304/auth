package com.fedex.cxs.springsecurity.vo;

import lombok.Data;
import lombok.ToString;

import com.fedex.cxs.calc.v3.vo.BaseProcessInputVO;


@ToString
public class LogoutInputVO extends BaseProcessInputVO{
	
	private String accessToken;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

}
