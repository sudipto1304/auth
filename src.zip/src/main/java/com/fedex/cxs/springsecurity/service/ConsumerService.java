package com.fedex.cxs.springsecurity.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.calc.exception.CALSystemException;
import com.fedex.cxs.calc.interfaces.accessgateway.LockDefinition;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.authn.AuthenticationProvider;
import com.fedex.cxs.calc.security.fcl.FclApiProvider;
import com.fedex.cxs.calc.security.fcl.FclIdentityProvider;
import com.fedex.cxs.calc.security.fcl.interfaces.FCLBoundary;
import com.fedex.cxs.calc.security.fcl.util.FCLErrorConstants;
import com.fedex.cxs.calc.transformation.util.ClientContextUtil;
import com.fedex.cxs.calc.util.OauthUtil;
import com.fedex.cxs.calc.util.fastfail.Lock;
import com.fedex.cxs.calc.v3.vo.ClientContextVO;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.exceptions.InvalidAuthenticationException;
import com.fedex.cxs.springsecurity.exceptions.InvalidTokenException;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.vo.LoginInputVO;
import com.fedex.fcl.api.FCLAPI;
import com.fedex.fcl.exceptions.FCLFatalException;

@Component
public class ConsumerService implements AuthConstant {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ConsumerService.class);

	
	private FCLAPI fclApi;

	public boolean login(LoginInputVO input, HttpServletRequest httpRequest)
			throws FCLFatalException, CALSystemException {
		LOGGER.info("FCL Loging for "+input.getUsername());
		this.fclApi = new FCLAPI();
		input.setHostName(CommonAuthConfig.getInstance().getOauthProperties()
				.getUsrchostname());
		ClientContextVO clientContextVO = new ClientContextUtil()
				.getClientContextV3(httpRequest);
		Map<String, String> fclHashMap = getLoginMap(input.getUsername(),
				input.getPassword());
		CXSContextHolder.getContext().setProperty(FCL_MAP, fclHashMap);
		loginProcessing(fclHashMap, input.getClientId());
		return true;

	}

	public boolean logout(String token) throws InvalidTokenException {
		this.fclApi = new FCLAPI();
		JSONObject body = OauthUtil.decryptToken(token, CommonAuthConfig.getInstance().getOauthProperties().getSignKey());
		ObjectMapper mapper = new ObjectMapper();
		RequestorIdentity identiry;
		try {
			identiry = mapper.readValue(body.toString(),
					RequestorIdentity.class);
			LOGGER.info("FCL logout for "+identiry.getAdditionalIdentity().get("UserName")+" with FCL Cookie :::"+identiry.getRawIdentity()+" and UUID::"+identiry.getIdentity());
			Map<String, String> fclHashMap = new HashMap<String, String>();
			fclHashMap.put(FCL_LOGIN_COOKIE_NAME, identiry.getRawIdentity());
			fclHashMap.put(FCL_LOGINMAP_UUID, identiry.getIdentity());
			CXSContextHolder.getContext().setProperty(FCL_MAP, fclHashMap);
		} catch (Exception e) {
			LOGGER.error("Token is invalid for consumer", e);
			throw new InvalidTokenException("Token is invalid for consumer");
		} 
		Cookie cookie = new Cookie("FDX_LOGIN", identiry.getRawIdentity());
		
		if (cookie != null) {
			try {
				LOGGER.debug("cookie passsed to FCL=={}",cookie.getValue());
				FCLBoundary.getInstance().logout(this.fclApi, cookie,
						new LockDefinition("FCL", 20));
			} catch (Exception e) {
				LOGGER.error("FCL Logout failed", e);
				throw new InvalidTokenException("FCL Logout failed");
			} 
		}
		return true;
	}

	private void loginProcessing(Map<String, String> fclHashMap, String clientId)
			throws FCLFatalException {
		boolean loginSuccessful = isLoginSuccessful(fclHashMap);
		if (loginSuccessful) {
			loginSuccessfulProcessing(fclHashMap, clientId);
		} else {
			loginUnsuccessfulProcessing(fclHashMap);
		}
	}

	private boolean isLoginSuccessful(Map<String, String> fclHashMap) {
		return "success".equals(fclHashMap.get("status"));
	}

	private void loginSuccessfulProcessing(Map<String, String> fclHashMap,
			String clientId) {
		String fclLoginCookieValue = (String) fclHashMap
				.get(FCL_LOGIN_COOKIE_NAME);
		if ("#-901".equals(fclLoginCookieValue)) {
			LOGGER.error("LOGIN.UNSUCCESSFUL.LASTATTEMPT");
			throw new InvalidAuthenticationException(
					"LOGIN.UNSUCCESSFUL.LASTATTEMPT");
		} else if ("#-902".equals(fclLoginCookieValue)) {
			LOGGER.error("LOGIN.UNSUCCESSFUL.EXCEEDED");
			throw new InvalidAuthenticationException(
					"LOGIN.UNSUCCESSFUL.EXCEEDED");
		}
		if (fclHashMap.containsKey(FCL_BREACH_STATUS)
				&& null != fclHashMap.get(FCL_BREACH_STATUS)) {
			String fclBreachStatusValue = (String) fclHashMap
					.get(FCL_BREACH_STATUS);
			LOGGER.debug("Breach_Status:  " + fclBreachStatusValue);
			if ("#-903".equals(fclBreachStatusValue)) {
				LOGGER.error("LOGIN.USER.DISABLED");
				throw new InvalidAuthenticationException("LOGIN.USER.DISABLED");

			}
		}
		LOGGER.debug("fdx_login:  " + fclHashMap.get(FCL_LOGIN_COOKIE_NAME));
		AuthenticationProvider.create(new FclIdentityProvider(
				new Lock(FCL, 20), fclLoginCookieValue));
		FclApiProvider.create(clientId);

	}

	private void loginUnsuccessfulProcessing(Map<String, String> fclHashMap)
			throws FCLFatalException {
		String errorCode = null;
		String fclLoginCookieValue = fclHashMap.get(FCL_LOGIN_COOKIE_NAME);
		String termsAndConditionsCookieValue = fclHashMap.get("tcdate");
		String checkEmailFlagCookieValue = fclHashMap.get("mailflag");
		errorCode = FCLErrorConstants.FCL_FATAL_ERROR;
		if ((fclLoginCookieValue == null) || ("".equals(fclLoginCookieValue))
				|| (fclLoginCookieValue.length() <= 5)) {
			LOGGER.error("LOGIN_UNSUCCESSFUL");
			errorCode = FCLErrorConstants.LOGIN_UNSUCCESSFUL;
		} else if ("unknown".equals(termsAndConditionsCookieValue)) {
			LOGGER.error("LOGIN_INFOSEC_NONCOMPLIANCE");
			errorCode = FCLErrorConstants.LOGIN_INFOSEC_NONCOMPLIANCE;
		} else if ("1".equals(checkEmailFlagCookieValue)) {
			LOGGER.error("LOGIN_INFOSEC_NONCOMPLIANCE");
			errorCode = FCLErrorConstants.LOGIN_INFOSEC_NONCOMPLIANCE;
		} else if (this.fclApi.checkInfosecCompliance().startsWith("T")) {
			LOGGER.error("LOGIN_INFOSEC_NONCOMPLIANCE");
			errorCode = FCLErrorConstants.LOGIN_INFOSEC_NONCOMPLIANCE;
		}

		throw new InvalidAuthenticationException(errorCode);
	}

	private Map<String, String> getLoginMap(String username, String password)
			throws FCLFatalException, CALSystemException {
		HashMap<String, String> loginHashMap = new HashMap<String, String>();
		loginHashMap.put(FCL_USERID, username);
		loginHashMap.put(FCL_PASSWORD, password);
		loginHashMap.put(FCL_APPNAME, FSM_APP_NAME);
		LOGGER.info("fclAppName :: " + FSM_APP_NAME);
		Map<String, String> fclHashMap = FCLBoundary.getInstance()
				.getloginHashMap(this.fclApi, loginHashMap,
						new LockDefinition("FCL", 20));
		LOGGER.info("FCL MAP::" + fclHashMap);
		return fclHashMap;
	}

}
