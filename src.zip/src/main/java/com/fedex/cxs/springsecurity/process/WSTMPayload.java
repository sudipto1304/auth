package com.fedex.cxs.springsecurity.process;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.ClientIdentity;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.vo.PersonaType;
import com.fedex.cxs.calc.security.wstm.authn.WstmAuthenticationProviderFactory;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.util.AuthUtil;

public class WSTMPayload implements Payload{
	
	
	private static final Logger Log = LoggerFactory
			.getLogger(WSTMPayload.class);
	
	
	private HttpServletRequest httpRequest; 
	private HttpServletResponse response;
	
	public WSTMPayload(HttpServletRequest httpRequest, HttpServletResponse response) {
		this.httpRequest = httpRequest;
		this.response = response;
	}

	@Override
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication) {
		WstmAuthenticationProviderFactory authProvider = new WstmAuthenticationProviderFactory();
		RequestorIdentity requestorIdentity = authProvider.getIdentityProvider(this.httpRequest, this.response).getIdentity();
		requestorIdentity.setPersonaType(PersonaType.Consumer);
		ClientIdentity clientIdentity = new ClientIdentity();
		clientIdentity.setClientKey(authentication.getOAuth2Request().getClientId());
		Map<String, String> moreInfo = new HashMap<String, String>();
		moreInfo.put(AuthConstant.TIMESTAMP, AuthUtil.getCurrentTime());
		moreInfo.put(AuthConstant.APPMODE, httpRequest.getHeader(AuthConstant.APPMODE));
		requestorIdentity.setAdditionalIdentity(moreInfo);
		requestorIdentity.setClientIdentity(clientIdentity);
		Log.debug("WSTM RequestorIdentity =>"+requestorIdentity );
		return requestorIdentity;
	}

}
