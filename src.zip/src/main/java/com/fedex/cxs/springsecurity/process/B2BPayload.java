package com.fedex.cxs.springsecurity.process;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.AuthenticationRealm;
import com.fedex.cxs.calc.security.ClientIdentity;
import com.fedex.cxs.calc.security.ConsumerIdentity;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.vo.PersonaType;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.util.AuthUtil;

public class B2BPayload implements Payload{

	
	private static final Logger Log = LoggerFactory
			.getLogger(B2BPayload.class);
	
	@Override
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication) {
		RequestorIdentity requestorIdentity = new RequestorIdentity();
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_REQUEST);
		requestorIdentity
				.setPersonaType(PersonaType.DirectIntegrator_B2B);
		ClientIdentity clientIdentity = new ClientIdentity();
		clientIdentity.setClientKey(authentication.getOAuth2Request().getClientId());
		Map<String, String> moreInfo = new HashMap<String, String>();
		moreInfo.put(AuthConstant.TIMESTAMP, AuthUtil.getCurrentTime());
		moreInfo.put(AuthConstant.APPMODE, httpRequest.getHeader(AuthConstant.APPMODE));
		requestorIdentity.setAdditionalIdentity(moreInfo);
		requestorIdentity.setAuthenticationRealm(AuthenticationRealm.CMAC);
		requestorIdentity.setClientIdentity(clientIdentity);
		Log.debug("B2B RequestorIdentity =>"+requestorIdentity );
		return requestorIdentity;
	}
	
	

}
