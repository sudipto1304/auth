package com.fedex.cxs.springsecurity.vo;

import lombok.Data;
import lombok.ToString;

import com.fedex.cxs.calc.v3.vo.BaseProcessOutputVO;


@Data
@ToString
public class LogoutOutputVO extends BaseProcessOutputVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String output;
	
	
	public LogoutOutputVO(String output) {
		this.output = output;
	}
}
