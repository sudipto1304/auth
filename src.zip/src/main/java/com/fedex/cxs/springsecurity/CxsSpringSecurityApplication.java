package com.fedex.cxs.springsecurity;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.tomcat.util.http.LegacyCookieProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.fedex.cxs.calc.config.CXSProperties;
import com.fedex.cxs.calc.config.Constants;
import com.fedex.cxs.calc.logging.util.CXSPatternLayout;
import com.fedex.cxs.springsecurity.util.DefaultProfileUtil;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.ConsoleAppender;
import ch.qos.logback.core.encoder.LayoutWrappingEncoder;

@SpringBootApplication
@EnableConfigurationProperties({ CXSProperties.class })
@EnableCaching
public class CxsSpringSecurityApplication {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CxsSpringSecurityApplication.class);
	
	
	@Autowired
	private Environment env;


	@PostConstruct
    public void initApplication() {
        LOGGER.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
        Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
        if (activeProfiles.contains(Constants.SPRING_PROFILE_DEVELOPMENT) && activeProfiles.contains(Constants.SPRING_PROFILE_PRODUCTION)) {
            LOGGER.error("You have misconfigured your application! It should not run " +
                "with both the 'dev' and 'prod' profiles at the same time.");
        }
        if (activeProfiles.contains(Constants.SPRING_PROFILE_DEVELOPMENT) && activeProfiles.contains(Constants.SPRING_PROFILE_CLOUD)) {
            LOGGER.error("You have misconfigured your application! It should not" +
                "run with both the 'dev' and 'cloud' profiles at the same time.");
        }
    }

	
	
	public static void main(String[] args) throws UnknownHostException {
		SpringApplication app = new SpringApplication(CxsSpringSecurityApplication.class);
		DefaultProfileUtil.addDefaultProfile(app);
        Environment env = app.run(args).getEnvironment();
        String protocol = "http";
        if (env.getProperty("server.ssl.key-store") != null) {
            protocol = "https";
        }
        LOGGER.info("\n----------------------------------------------------------\n\t" +
                "Fedex CXS Application '{}' is running! Access URLs:\n\t" +
                "Local: \t\t{}://localhost:{}\n\t" +
                "External: \t{}://{}:{}\n\t" +
                "Profile(s): \t{}\n----------------------------------------------------------",
            env.getProperty("spring.application.name"),
            protocol,
            env.getProperty("server.port"),
            protocol,
            InetAddress.getLocalHost().getHostAddress(),
            env.getProperty("server.port"),
            env.getActiveProfiles());
        
        String configServerStatus = env.getProperty("configserver.status");
        LOGGER.info("\n----------------------------------------------------------\n\t" +
        "Config Server: {}\t status:{}\n----------------------------------------------------------",
        	env.getProperty("spring.cloud.config.uri"),
            configServerStatus == null ? "Not found or not setup for this application" : configServerStatus);

	}

	
	@Bean
	public WebServerFactoryCustomizer<TomcatServletWebServerFactory> customizer() {
	    return container -> {
	        if (container instanceof TomcatServletWebServerFactory) {
	        	TomcatServletWebServerFactory tomcat = (TomcatServletWebServerFactory) container;
	            tomcat.addContextCustomizers(context -> context.setCookieProcessor(new LegacyCookieProcessor()));
	        }
	    };
	}
	
	
	
	
	
	
	
}

