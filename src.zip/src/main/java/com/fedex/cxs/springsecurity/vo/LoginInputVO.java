package com.fedex.cxs.springsecurity.vo;

import lombok.Data;
import lombok.ToString;

import com.fedex.cxs.calc.v3.vo.BaseProcessInputVO;

@Data
@ToString
public class LoginInputVO extends BaseProcessInputVO{

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	private String username;
	private String password;
	private String hostName;
	private String clientId;
}
