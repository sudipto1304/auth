package com.fedex.cxs.springsecurity.process.interfaces;

import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.RequestorIdentity;

public interface Payload {
	
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication);

}
