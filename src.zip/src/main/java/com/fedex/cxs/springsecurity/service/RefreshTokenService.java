package com.fedex.cxs.springsecurity.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.fcl.FclIdentityProvider;
import com.fedex.cxs.calc.util.fastfail.Lock;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.exceptions.InvalidAuthenticationException;
import com.fedex.cxs.springsecurity.exceptions.InvalidInputParameterException;
import com.fedex.cxs.springsecurity.util.AuthConstant;


@Component
public class RefreshTokenService implements UserDetailsService{

	
	private static final Logger Log = LoggerFactory.getLogger(RefreshTokenService.class);
	
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	
	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext()
				.getProperty(AuthConstant.HTTP_REQUEST);
		String refreshToken = httpRequest.getParameter("refresh_token");
		JSONObject payLoad = getAuthentication(refreshToken);
		if (payLoad==null) {
			throw new InvalidInputParameterException(AuthConstant.INVALID_INPUT);
		}
		ObjectMapper mapper = new ObjectMapper();
		RequestorIdentity identity=null;
		try {
			identity = mapper.readValue(payLoad.get("Payload").toString(), RequestorIdentity.class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		FclIdentityProvider provider = new FclIdentityProvider(getIdentityLock(), identity);
		if(provider.isAuthenticated()){
			User users = new User(username, encoder.encode(identity.getRawIdentity()), new ArrayList<>());
			return users;
		}else{
			throw new InvalidAuthenticationException(AuthConstant.SESSION_EXPIRED);
		}
	}
	
	
	private JSONObject getAuthentication(String refreshToken) {
		if (Log.isDebugEnabled())
			Log.debug("Token inside RefreshTokenService::" + refreshToken);
		if (refreshToken != null) {
			String[] split_string = refreshToken.split("\\.");
			String base64EncodedHeader = split_string[0];
			String base64EncodedBody = split_string[1];
			String base64EncodedSignature = split_string[2];
			Base64 base64Url = new Base64(true);
			String header = new String(base64Url.decode(base64EncodedHeader));
			String body = new String(base64Url.decode(base64EncodedBody));
			JSONObject json = null;
			try {
				json = new JSONObject(body);
				if (Log.isDebugEnabled())
					Log.debug("Token body::" + json);

			} catch (Exception e) {
				return null;
			}
			return json;
		}
		if (Log.isErrorEnabled())
			Log.error("Refresh token is null");
		return null;
	}

	
	
	protected Lock getIdentityLock() {
		return new Lock("FCL", 20);
	}


	
}
