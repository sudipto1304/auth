package com.fedex.cxs.springsecurity.process;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.util.AuthUtil;

public class EmptyPersonaPayload implements Payload{

	@Override
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication) {
		RequestorIdentity requestorIdentity = new RequestorIdentity();
		Map<String, String> moreInfo = new HashMap<String, String>();
		moreInfo.put("Created", AuthUtil.getCurrentTime());
		requestorIdentity.setAdditionalIdentity(moreInfo);
		return requestorIdentity;
	}

}
