package com.fedex.cxs.springsecurity.util;

public interface AuthConstant {

	String CLIENT_CREDENTIALS = "client_credentials";
	String B2C_CUSTOM = "B2C_Custom";
	String REFRESH_TOKEN = "refresh_token";
	String CSP_CREDENTIALS = "csp_credentials";
	String SCOPE = "scope";
	String GRANT_TYPE = "grant_type";
	String SECRET = "client_secret";
	String SCOPE_CAPS = "SCOPE";
	String SCOPE_CXS = "CXS";
	String SCOPE_SECURE = "SECURE";
	String SUCCESS = "SUCCESS";
	String ERROR = "ERROR";
	String INTERNAL_SECRET = "secret";
	String SCOPE_WRITE = "write";
	String HTTP_REQUEST = "httpRequest";
	String HTTP_RESPONSE = "httpResponse";
	String GRANT_TYPE_PASSWORD = "password";
	String LOGOUT_GRANT_TYPE = "logout";
	String TRUST = "trust";
	int ACCESS_TOKEN_VALID = 60*60; //60 Mins
	int REFRESH_TOKEN_VALID = 60*60*5; //5 Hours
	String PROVIDERS = "providers";
	String REQUESTER_IDENTITY = "RequesterIdentity";
	String AUTHORIZATION = "Authorization";
	String PAYLOAD = "Payload";
	String CHILD_KEY = "child_key";
	String ACCESS_TOKEN = "accessToken";
	String CHILD_SECRET = "child_secret";
	String INVALID_INPUT = "Full authentication is required to access this resource";
	String CMAC_ERROR_MSG = "Invalid credential combination";
	String INVALID_LOGIN_CREDENTIALS = "Invalid Credentials, Login Failed";
	String SESSION_EXPIRED = "Consumer session is expired. Generate new access token";
	String WSTM_HEADER = "FDX_UUID";
	String WSSO_HEADER = "OBLIX_UID";
	String CSP_IDENTITY = "CSPIdentity";
	String LOGOUT_RI = "LogOutRI";
	String APPMODE = "apimode";
	String TIMESTAMP = "timeStamp";
	 String FCL = "FCL";

	 String FCL_FATAL_ERROR = "FCL.FATAL.ERROR";

	 String LOGIN_UNSUCCESSFUL = "LOGIN.UNSUCCESSFULTYPE.ERROR";
	// Cookie names
	 String FCL_USER_COOKIE_NAME = "fcl_fname";
	 String FCL_LOGIN_COOKIE_NAME = "fdx_login";
	 String FCL_UUID_COOKIE_NAME = "fcl_uuid";
	 String FCL_SMSESSION_COOKIE_NAME = "SMSESSION";
	 String FCL_CONTACTNAME_COOKIE_NAME = "fcl_contactname";
	 String FCL_BREACH_STATUS = "breachStatus";

	 String FCL_COOKIE_DOMAIN = ".fedex.com";
	 String FCL_COOKIE_PATH = "/";
	// Login HashMap keys
	 String FCL_USERID = "userid";
	 String FCL_MAP = "fcl_map";
	 String FCL_PASSWORD = "password";
	 String FCL_APPNAME = "appname";
	 String FCL_LOGINMAP_UUID = "uuid";
	 String FSM_APP_NAME="fclfsm";
	 String CMAC_HOST_KEY="cmac.authN.service.hostname";
	 String CMAC_API_KEY="cmac.authN.service.uri";
	 
	 
	 String INVALID_TOKEN_CODE = "401";
	 String INVALID_TOKEN_MSG = "Invalid token for authentication";
}
