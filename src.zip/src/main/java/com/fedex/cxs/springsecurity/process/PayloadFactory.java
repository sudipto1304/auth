package com.fedex.cxs.springsecurity.process;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.util.AuthConstant;

public class PayloadFactory {

	public static Payload getInstance(String grantType) {
		if (AuthConstant.CSP_CREDENTIALS.equals(grantType)) {
			return new CSPPayload();
		} else if (AuthConstant.GRANT_TYPE_PASSWORD.equals(grantType) || AuthConstant.B2C_CUSTOM.equals(grantType)) {
			return new ConsumerPayload();
		} else if (AuthConstant.CLIENT_CREDENTIALS.equals(grantType) || AuthConstant.LOGOUT_GRANT_TYPE.equals(grantType)) {
			HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext()
					.getProperty(AuthConstant.HTTP_REQUEST);
			if (StringUtils.isNotEmpty(httpRequest.getHeader(AuthConstant.WSSO_HEADER))) {
				return new EmployeePayload(httpRequest,
						(HttpServletResponse) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_RESPONSE));
			} else if (StringUtils.isNotEmpty(httpRequest.getHeader(AuthConstant.WSTM_HEADER))) {
				return new WSTMPayload(httpRequest,
						(HttpServletResponse) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_RESPONSE));
			} else {
				return new B2BPayload();
			}
		} else {
			return new EmptyPersonaPayload();
		}
	}

}
