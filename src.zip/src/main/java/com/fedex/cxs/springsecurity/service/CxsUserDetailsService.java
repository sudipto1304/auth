package com.fedex.cxs.springsecurity.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.exceptions.InvalidAuthenticationException;
import com.fedex.cxs.springsecurity.exceptions.InvalidInputParameterException;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.vo.LoginInputVO;

@Component
public class CxsUserDetailsService implements UserDetailsService {

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Autowired
	private ConsumerService1 consumerService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext()
				.getProperty(AuthConstant.HTTP_REQUEST);
		String userName = httpRequest.getParameter("username");
		String password = httpRequest.getParameter("password");
		if (StringUtils.isEmpty(userName) || StringUtils.isEmpty(password)) {
			throw new InvalidInputParameterException(AuthConstant.INVALID_INPUT);
		}
		LoginInputVO request = new LoginInputVO();
		request.setClientId(httpRequest.getParameter("client_id"));
		request.setPassword(password);
		request.setUsername(userName);
		boolean response = false;
		try {
			response = consumerService.login(request, httpRequest);
			User users = new User(request.getUsername(), encoder.encode(request.getPassword()), new ArrayList<>());
			return users;
		} catch (Exception e) {
			throw new InvalidAuthenticationException(AuthConstant.INVALID_LOGIN_CREDENTIALS);
		}
	}

}
