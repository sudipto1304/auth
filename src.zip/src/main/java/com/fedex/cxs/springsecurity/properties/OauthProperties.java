package com.fedex.cxs.springsecurity.properties;

import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Component
@ConfigurationProperties("fedex.oauth")
public class OauthProperties {
	
	private String clientId;
	private String clientSecret;
	private String signKey;
	private String usrchostname;
	private int directIntegratorTokenTimeout;
	private int compatibleProviderTokenTimeout;
	private String jwtSignature;
	private boolean enableEncryption;
	private boolean enableCertificateSign;
	private REST rest = new REST();
	
	private Key prodkey = new Key();
	private Key testkey = new Key();
	
	
	@Data
	@ToString
	public static class Key {
		private String keystorePassCode;
		private String keystoreAlias;
		private String key;
	}
	
	
	@Data
	@ToString
	public static class REST {
		private Properties uriConfigProperties = new Properties();
	}


}
