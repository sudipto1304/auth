
package com.fedex.cxs.springsecurity.process;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fedex.cxs.calc.security.AuthenticationRealm;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.vo.PersonaType;
import com.fedex.cxs.clc.security.cmac.CmacIdentiyProvider;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.interfaces.Payload;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.util.AuthUtil;
@SuppressWarnings("unused")

public class CSPPayload implements Payload{
	
	private static final Logger Log = LoggerFactory
			.getLogger(CSPPayload.class);

	@Override
	public RequestorIdentity getRequesterIdentity(OAuth2Authentication authentication) {
		RequestorIdentity identity = (RequestorIdentity) CXSContextHolder.getContext().getProperty(AuthConstant.CSP_CREDENTIALS);
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_REQUEST);
		CXSContextHolder.getContext().removeProperty(AuthConstant.CSP_CREDENTIALS);
		Map<String, String> moreInfo = new HashMap<String, String>();
		moreInfo.put(AuthConstant.TIMESTAMP, AuthUtil.getCurrentTime());
		moreInfo.put(AuthConstant.APPMODE, httpRequest.getHeader(AuthConstant.APPMODE));
		identity.setAdditionalIdentity(moreInfo);
		identity.setAuthenticationRealm(AuthenticationRealm.CMAC);
		Log.debug("CSP RequestorIdentity =>"+identity );
		return identity;
	}

}
