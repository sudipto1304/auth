package com.fedex.cxs.springsecurity.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.CompositeTokenGranter;
import org.springframework.security.oauth2.provider.TokenGranter;
import org.springframework.security.oauth2.provider.client.ClientCredentialsTokenGranter;
import org.springframework.security.oauth2.provider.request.DefaultOAuth2RequestFactory;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.rsa.crypto.KeyStoreKeyFactory;

import com.fedex.cxs.calc.config.CXSProperties;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.service.ConsumerNonPasswordCustomTokenGranter;
import com.fedex.cxs.springsecurity.service.CspCustomTokenGranter;
import com.fedex.cxs.springsecurity.service.CustomTokenEnhancer;
import com.fedex.cxs.springsecurity.service.CxsClientDetailsService;
import com.fedex.cxs.springsecurity.service.LogoutTokenGranter;
import com.fedex.cxs.springsecurity.service.RefreshTokenService;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {
	
	private static final Logger Log = LoggerFactory
			.getLogger(AuthorizationServerConfig.class);

	@Autowired
	private AuthenticationManager authManager;

	@Bean
	public CXSProperties getCXSProperties() {
		return new CXSProperties();
	}
	
	@Autowired
	private RefreshTokenService refreshTokenService;


	@Autowired
	private CxsClientDetailsService clientDetailsService;

	
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		 JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
		 if(!CommonAuthConfig.getInstance().getOauthProperties().isEnableCertificateSign()){
			 Log.debug("Certificate Sign disable::signing with symmetric key");
			 converter.setSigningKey(CommonAuthConfig.getInstance().getOauthProperties().getJwtSignature());
		 }
		 return converter;
		 
	}
	

	@Bean
	public TokenStore tokenStore() {
		return new JwtTokenStore(accessTokenConverter());
	}

	
	@Override
	public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
		security.allowFormAuthenticationForClients();
	}

	@Override
	public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
		clients.withClientDetails(clientDetailsService);
	}

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
		final TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
        tokenEnhancerChain.setTokenEnhancers(
          Arrays.asList(tokenEnhancer(), accessTokenConverter()));
        endpoints.tokenGranter(tokenGranter(endpoints)).tokenStore(tokenStore())
        .tokenEnhancer(tokenEnhancerChain)
        .accessTokenConverter(accessTokenConverter())
                .authenticationManager(authManager).userDetailsService(refreshTokenService);
	}

	private TokenGranter tokenGranter(final AuthorizationServerEndpointsConfigurer endpoints) {
		List<TokenGranter> granters = new ArrayList<TokenGranter>(Arrays.asList(endpoints.getTokenGranter()));
		granters.add(new CspCustomTokenGranter(tokenServices(), clientDetailsService, oauth2RequestFactory(),
				AuthConstant.CSP_CREDENTIALS));
		granters.add(new LogoutTokenGranter(tokenServices(), clientDetailsService, oauth2RequestFactory(),
				AuthConstant.LOGOUT_GRANT_TYPE));
		granters.add(new ConsumerNonPasswordCustomTokenGranter(tokenServices(), clientDetailsService, oauth2RequestFactory()));
		ClientCredentialsTokenGranter clientCredentialsTokenGranter = new ClientCredentialsTokenGranter(tokenServices(), clientDetailsService, oauth2RequestFactory());
		clientCredentialsTokenGranter.setAllowRefresh(true);
		granters.add(clientCredentialsTokenGranter);
		return new CompositeTokenGranter(granters);
	}

	@Bean
	@Primary
	public DefaultTokenServices tokenServices() {
		TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
		tokenEnhancerChain.setTokenEnhancers(Arrays.asList(tokenEnhancer(), accessTokenConverter()));
		final DefaultTokenServices services = new DefaultTokenServices();
		services.setClientDetailsService(clientDetailsService);
		services.setTokenStore(tokenStore());
		services.setTokenEnhancer(tokenEnhancerChain);
		return services;
	}

	@Bean
	public DefaultOAuth2RequestFactory oauth2RequestFactory() {
		final DefaultOAuth2RequestFactory defaultTokenServices = new DefaultOAuth2RequestFactory(clientDetailsService);
		return defaultTokenServices;
	}

	@Bean
	public TokenEnhancer tokenEnhancer() {
		return new CustomTokenEnhancer();
	}
	
	

}