package com.fedex.cxs.springsecurity.transaction;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.calc.exception.CALException;
import com.fedex.cxs.calc.exception.CALSystemException;
import com.fedex.cxs.calc.rest.client.transaction.PostTransaction;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.v3.vo.ClientContextVO;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.vo.LoginInputVO;

public class USRCLoginTransaction extends PostTransaction{

	private static final Logger LOGGER = LoggerFactory.getLogger(USRCLoginTransaction.class);
	
	public  final static String END_POINT_URI_KEY ="usrc.login.service";
	
	private LoginInputVO loginInputVO;
	
	public USRCLoginTransaction(LoginInputVO loginInputVO, ClientContextVO clientContextVO, RequestorIdentity requestorIdentity){
		
		super(CommonAuthConfig.getInstance().getURIConfigProperties(), END_POINT_URI_KEY, clientContextVO, requestorIdentity);
		this.loginInputVO = loginInputVO;
	}
	
//	public LoginCookieOutputVO executeTransaction() throws CALException{
//		RestTemplate template = new RestTemplate();
//		String usrcLoginApi = "https://"
//				+ CommonAuthConfig.getInstance().getURIConfigProperties().getProperty(END_POINT_URI_KEY + ".hostname")
//				+ CommonAuthConfig.getInstance().getURIConfigProperties().getProperty(END_POINT_URI_KEY+ ".uri");
//		LOGGER.info("USRC Login call API: " + usrcLoginApi);
//		HttpHeaders headers = new HttpHeaders();
//		headers.add("Content-Type", "application/json");
//		headers.add("X-clientid", "WCDO");
//		HttpEntity<LoginInputVO1> request = new HttpEntity<LoginInputVO1>(loginInputVO, headers);
//		LoginCookieOutputVO response = template.postForObject(usrcLoginApi, request, LoginCookieOutputVO.class);
//		LOGGER.info("USRC Login response: " + response);
//		return response;
//	}


	@Override
	protected String createRequest() throws CALException {
		String postData = null;
		if (null != this.loginInputVO) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			try {
				postData = mapper
						.writeValueAsString(this.loginInputVO);
				LOGGER.debug("USRCLoginTransaction::createRequest: USRC request:: " + postData);
			} catch (IOException e) {
				LOGGER.error("ERROR::USRCLoginTransaction::", e);
				throw new CALSystemException(e);
			}
		}
		return postData;

	}
	
}
