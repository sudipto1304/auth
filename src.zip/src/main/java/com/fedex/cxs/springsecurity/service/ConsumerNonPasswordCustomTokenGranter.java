package com.fedex.cxs.springsecurity.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.token.AbstractTokenGranter;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import com.fedex.cxs.calc.security.AuthenticationRealm;
import com.fedex.cxs.calc.security.ClientIdentity;
import com.fedex.cxs.calc.security.ConsumerIdentity;
import com.fedex.cxs.calc.security.vo.PersonaType;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.util.AuthUtil;

public class ConsumerNonPasswordCustomTokenGranter extends AbstractTokenGranter{

	
	public ConsumerNonPasswordCustomTokenGranter(AuthorizationServerTokenServices tokenServices,
			ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory) {
		this(tokenServices, clientDetailsService, requestFactory, AuthConstant.B2C_CUSTOM);
	}
	
	
	protected ConsumerNonPasswordCustomTokenGranter(AuthorizationServerTokenServices tokenServices,
			ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, String grantType) {
		super(tokenServices, clientDetailsService, requestFactory, grantType);
		
	}
	
	
	@Override
	public OAuth2AccessToken grant(String grantType, TokenRequest tokenRequest) {
		OAuth2AccessToken token = super.grant(grantType, tokenRequest);
		return token;
	}
	

}
