package com.fedex.cxs.springsecurity.exceptions;

import org.springframework.security.core.AuthenticationException;

public class InvalidInputParameterException extends AuthenticationException{

	public InvalidInputParameterException(String msg) {
		super(msg);
	}

}
