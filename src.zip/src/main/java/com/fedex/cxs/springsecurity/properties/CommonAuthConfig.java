package com.fedex.cxs.springsecurity.properties;

import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CommonAuthConfig implements InitializingBean {

	private static CommonAuthConfig instance;
	@Autowired
	private OauthProperties oauthProperties;

	@Override
	public void afterPropertiesSet() throws Exception {
		instance = this;
	}

	public static CommonAuthConfig getInstance() {
		return instance;
	}

	public Properties getURIConfigProperties() {
		return this.oauthProperties.getRest().getUriConfigProperties();
	}
	
	public OauthProperties getOauthProperties() {
		return this.oauthProperties;
	}
}
