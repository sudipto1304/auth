package com.fedex.cxs.springsecurity.vo;

import org.springframework.security.oauth2.provider.client.BaseClientDetails;

import lombok.Data;
import lombok.ToString;


@Data
@ToString
public class CxsClientDetails extends BaseClientDetails {

	
}
