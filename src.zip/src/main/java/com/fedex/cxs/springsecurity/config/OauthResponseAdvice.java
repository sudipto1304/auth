package com.fedex.cxs.springsecurity.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fedex.cxs.calc.exception.ALERTTYPE;
import com.fedex.cxs.calc.exception.CXSAlert;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.exceptions.InvalidTokenException;
import com.fedex.cxs.springsecurity.util.AuthConstant;
import com.fedex.cxs.springsecurity.vo.LogoutOutputVO;

@ControllerAdvice
public class OauthResponseAdvice extends ResponseEntityExceptionHandler implements ResponseBodyAdvice<Object>{

	private static final Logger Log = LoggerFactory
			.getLogger(OauthResponseAdvice.class);
	@Override
	public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	@Override
	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
			Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request,
			ServerHttpResponse response) {
		if(body instanceof DefaultOAuth2AccessToken ) {
			DefaultOAuth2AccessToken tokenResponse = (DefaultOAuth2AccessToken)body;
			try {
				RequestorIdentity identity = (RequestorIdentity) tokenResponse.getAdditionalInformation().get(AuthConstant.PAYLOAD);
				Log.info("Token generated for "+identity.getPersonaType());
			} catch (Exception e) {
				
			}
			tokenResponse.getAdditionalInformation().clear();
			body = tokenResponse;
			Log.info("setting Access-Control-Allow-Origin to *");
				
			((ServletServerHttpResponse)response).getServletResponse().addHeader("Access-Control-Allow-Credentials", "true");
			((ServletServerHttpResponse)response).getServletResponse().addHeader("Access-Control-Allow-Origin", "*");
			
			CXSContextHolder.getContext().removeProperty(AuthConstant.FCL_MAP);
		}
		return body;
	}
	
	
	@ExceptionHandler(InvalidTokenException.class)
	protected ResponseEntity<Object> handleException(InvalidTokenException e , WebRequest w){
		Log.error("Token generation failed "+e.getMessage());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		LogoutOutputVO output = new LogoutOutputVO(AuthConstant.ERROR);
		CXSAlert alert = new CXSAlert(AuthConstant.INVALID_TOKEN_CODE, AuthConstant.INVALID_TOKEN_MSG, ALERTTYPE.WARNING);
		output.addAlert(alert);
		return handleExceptionInternal(e, output, headers, HttpStatus.BAD_REQUEST, w);
	}
	
	
	
	
	

}
