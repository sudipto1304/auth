package com.fedex.cxs.springsecurity.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthUtil {
	
	private static final Logger Log = LoggerFactory.getLogger(AuthUtil.class);
	
	public static JSONObject decryptToken(String token) {
		if (Log.isDebugEnabled())
			Log.debug("Token inside AuthUtil::" + token);
		if (token != null) {
			String[] split_string = token.split("\\.");
			String base64EncodedHeader = split_string[0];
			String base64EncodedBody = split_string[1];
			String base64EncodedSignature = split_string[2];
			Base64 base64Url = new Base64(true);
			String header = new String(base64Url.decode(base64EncodedHeader));
			String body = new String(base64Url.decode(base64EncodedBody));
			JSONObject json = null;
			try {
				json = new JSONObject(body);
				if (Log.isDebugEnabled())
					Log.debug("Token body::" + json);

			} catch (Exception e) {
				return null;
			}
			return json;
		}
		if (Log.isErrorEnabled())
			Log.error(" token is null");
		return null;
	}
	
	
	public static String getCurrentTime(){
		Date date  = new Date();
		DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss z");
		formatter.setTimeZone(TimeZone.getTimeZone("EST"));
		return formatter.format(date);
		
	}
	
	


}
