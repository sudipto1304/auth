package com.fedex.cxs.springsecurity.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.fedex.cxs.calc.config.CXSProperties;
import com.fedex.cxs.springsecurity.filter.CXSSpringSecurityAuthFilter;
import com.fedex.cxs.springsecurity.service.CxsUserDetailsService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private CxsUserDetailsService userDetailsService;
	
	private final Environment env;
	
	@SuppressWarnings("unused")
	private final CXSProperties cxsProperties;
	
	 public WebSecurityConfig(Environment env, CXSProperties cxsProperties) {

	        this.env = env;
	        this.cxsProperties = cxsProperties;
	        
	    }
	
	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth)
			throws Exception {
		auth.userDetailsService(userDetailsService);
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
	

	@Bean
	public FilterRegistrationBean customFilterRegistrationBean() {
	    FilterRegistrationBean registrationBean = new FilterRegistrationBean();
	    CXSSpringSecurityAuthFilter userFilter = new CXSSpringSecurityAuthFilter();
	    registrationBean.setFilter(userFilter);
	    registrationBean.setOrder(Integer.MIN_VALUE);
	    return registrationBean;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().authorizeRequests().anyRequest().permitAll();
	}
	
	
	
}
