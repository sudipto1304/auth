package com.fedex.cxs.springsecurity.service;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.rsa.crypto.KeyStoreKeyFactory;
import org.springframework.stereotype.Component;

import com.fedex.cxs.calc.util.OauthUtil;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.config.AuthorizationServerConfig;
import com.fedex.cxs.springsecurity.process.PayloadFactory;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@Component
public class CustomTokenEnhancer implements TokenEnhancer {
	private static final Logger Log = LoggerFactory
			.getLogger(CustomTokenEnhancer.class);
	
	@Autowired
	public JwtAccessTokenConverter tokenConverter;
	
	@Override
	public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
		Map<String, Object> additionalInfo = new HashMap<>();
		HttpServletRequest httpRequest = (HttpServletRequest) CXSContextHolder.getContext().getProperty(AuthConstant.HTTP_REQUEST);
		String appMode = httpRequest.getHeader(AuthConstant.APPMODE);
		String grantType = authentication.getOAuth2Request().getGrantType();
		if(CommonAuthConfig.getInstance().getOauthProperties().isEnableEncryption()) {
				additionalInfo.put(AuthConstant.PAYLOAD,
				OauthUtil.encrypt(PayloadFactory.getInstance(grantType).getRequesterIdentity(authentication), CommonAuthConfig.getInstance().getOauthProperties().getSignKey()));
		}else {
					additionalInfo.put(AuthConstant.PAYLOAD, PayloadFactory.getInstance(grantType).getRequesterIdentity(authentication));
		}
		((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);
		if(CommonAuthConfig.getInstance().getOauthProperties().isEnableCertificateSign()){
			Log.debug("Certificate Sign enable");
			if("live".equalsIgnoreCase(appMode)) {
				Log.debug("Signing with prod key:::"+CommonAuthConfig.getInstance().getOauthProperties().getProdkey());
				KeyStoreKeyFactory keyStoreKeyFactory = 
						 new KeyStoreKeyFactory(new ClassPathResource(CommonAuthConfig.getInstance().getOauthProperties().getProdkey().getKey()), CommonAuthConfig.getInstance().getOauthProperties().getProdkey().getKeystorePassCode().toCharArray());
				tokenConverter.setKeyPair(keyStoreKeyFactory.getKeyPair(CommonAuthConfig.getInstance().getOauthProperties().getProdkey().getKeystoreAlias()));
			}else {
				Log.debug("Signing with test key::"+CommonAuthConfig.getInstance().getOauthProperties().getTestkey());
				KeyStoreKeyFactory keyStoreFactory = new KeyStoreKeyFactory(new ClassPathResource(CommonAuthConfig.getInstance().getOauthProperties().getTestkey().getKey()), CommonAuthConfig.getInstance().getOauthProperties().getTestkey().getKeystorePassCode().toCharArray());
				tokenConverter.setKeyPair(keyStoreFactory.getKeyPair(CommonAuthConfig.getInstance().getOauthProperties().getTestkey().getKeystoreAlias()));
			}
		}
		
		CXSContextHolder.getContext().removeProperty(AuthConstant.HTTP_REQUEST);
		CXSContextHolder.getContext().removeProperty(AuthConstant.HTTP_RESPONSE);
		return accessToken;
	}

	
}
