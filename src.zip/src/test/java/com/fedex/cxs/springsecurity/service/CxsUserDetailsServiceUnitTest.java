package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*"})
@PrepareForTest({ CXSContextHolder.class, CxsUserDetailsService.class })
public class CxsUserDetailsServiceUnitTest {

	private BCryptPasswordEncoder encoder;
	private ConsumerService consumerService;
	private CxsUserDetailsService cxsUserDetailsService;
	
	@Before
	public void setup() throws Exception{
		mockCXSContextHolder();
		User user = PowerMockito.mock(User.class);
		PowerMockito.whenNew(User.class).withAnyArguments().thenReturn(user);
		
		encoder = PowerMockito.mock(BCryptPasswordEncoder.class);
		consumerService = PowerMockito.mock(ConsumerService.class);
		cxsUserDetailsService = new CxsUserDetailsService();
		ReflectionTestUtils.setField(cxsUserDetailsService, "encoder", encoder);
		ReflectionTestUtils.setField(cxsUserDetailsService, "consumerService", consumerService);
	}
	
	@Test
	public void loadUserByUsernameTest(){
		UserDetails output = cxsUserDetailsService.loadUserByUsername("userName");
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getParameter("username")).thenReturn("userName");
		when(httpRequest.getParameter("password")).thenReturn("password");
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
