package com.fedex.cxs.springsecurity.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.springsecurity.CxsSpringSecurityApplication;
import com.fedex.cxs.springsecurity.service.ConsumerService;
import com.fedex.cxs.springsecurity.vo.LogoutInputVO;
import com.netflix.hystrix.Hystrix;
import com.netflix.hystrix.strategy.HystrixPlugins;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@ContextConfiguration(classes = { CxsSpringSecurityApplication.class })
public class ConsumerControllerUnitTest {
	
	@MockBean
	private ConsumerService service;

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Before
	public void setUp() throws Exception {
		HystrixPlugins.reset();
		Hystrix.reset();
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
   
	@After
	public void reset() {
		HystrixPlugins.reset();
		Hystrix.reset();
	}
	
	@Test
	public void testLogOutResponseEntityUnsuccessful() throws Exception{
		LogoutInputVO input = new LogoutInputVO();
		when(service.logout(input.getAccessToken())).thenReturn(false);
		mockMvc.perform(post("/token/action/logout").contentType("application/json").content(
				 new ObjectMapper().writeValueAsString(input)))
		 		.andDo(print()).andExpect(status().is(400));
	}
	
	@Test
	public void testLogOutResponseEntitySuccessful() throws Exception{
		LogoutInputVO input = new LogoutInputVO();
		when(service.logout(input.getAccessToken())).thenReturn(true);
		mockMvc.perform(post("/token/action/logout").contentType("application/json").content(
				 new ObjectMapper().writeValueAsString(input)))
		 		.andDo(print()).andExpect(status().is(200));
	}

}
