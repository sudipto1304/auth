package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.cxsspringsecurity.process.BaseAuthServerTest;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({ CXSContextHolder.class })
public class CxsClientDetailsServiceUnitTest extends BaseAuthServerTest {

	private BCryptPasswordEncoder encoder;
	private CxsClientDetailsService cxsClientDetailsService;
	
	@Before
	public void setup(){
		mockCommonAuthConfig();
		encoder = PowerMockito.mock(BCryptPasswordEncoder.class);
		cxsClientDetailsService = new CxsClientDetailsService();
		ReflectionTestUtils.setField(cxsClientDetailsService, "encoder", encoder);
	}
	
	@Test
	public void loadClientByClientIdTest(){
		mockCXSContextHolder("");
		ClientDetails output = cxsClientDetailsService.loadClientByClientId("clientId");
		Assert.assertNotNull(output);
	}
	
	@Test
	public void loadClientByClientIdTestClient(){
		mockCXSContextHolder(AuthConstant.CLIENT_CREDENTIALS);
		ClientDetails output = cxsClientDetailsService.loadClientByClientId("clientId");
		Assert.assertNotNull(output);
	}
	
	@Test
	public void loadClientByClientIdCSP(){
		mockCXSContextHolder(AuthConstant.CSP_CREDENTIALS);
		ClientDetails output = cxsClientDetailsService.loadClientByClientId("clientId");
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(String grantType){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getParameter(AuthConstant.GRANT_TYPE)).thenReturn(grantType);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
