package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.clc.security.cmac.CmacIdentiyProvider;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.cxsspringsecurity.process.BaseAuthServerTest;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({CspCustomTokenGranter.class, CmacIdentiyProvider.class, CXSContextHolder.class})
public class CSPCustomTokenGranterUnitTest extends BaseAuthServerTest{
	
	@Mock
	private AuthorizationServerTokenServices tokenServices;
	@Mock
	private ClientDetailsService clientDetailsService;
	@Mock
	private OAuth2RequestFactory requestFactory;
	
	private CspCustomTokenGranter customTokenGranter;
	private String grantType = "grant";
	
	@Before
	public void setup(){
		mockCommonAuthConfig();
	}
	
	@Test
	public void grantTokenTest() throws Exception{
		ClientDetails clientDetails = PowerMockito.mock(ClientDetails.class);
		when(clientDetailsService.loadClientByClientId("id")).thenReturn(clientDetails);
		
		customTokenGranter = new CspCustomTokenGranter(tokenServices,clientDetailsService,requestFactory,grantType);
		
		TokenRequest tokenRequest = PowerMockito.mock(TokenRequest.class);
		when(tokenRequest.getClientId()).thenReturn("id");
		Map<String, String> requestParameters = new HashMap<>();
		requestParameters.put(AuthConstant.CHILD_KEY, "key");
		requestParameters.put(AuthConstant.CHILD_SECRET, "secret");
		when(tokenRequest.getRequestParameters()).thenReturn(requestParameters);
		
		CmacIdentiyProvider identityProvider = PowerMockito.mock(CmacIdentiyProvider.class);
		RequestorIdentity identity = PowerMockito.mock(RequestorIdentity.class);
		when(identityProvider.getIdentity()).thenReturn(identity);
		PowerMockito.whenNew(CmacIdentiyProvider.class).withAnyArguments().thenReturn(identityProvider);
		
		OAuth2Request auth2Request = PowerMockito.mock(OAuth2Request.class);
		when(requestFactory.createOAuth2Request(clientDetails, tokenRequest)).thenReturn(auth2Request);
		
		OAuth2Authentication authAuthentication = new OAuth2Authentication(auth2Request,null);
		
		OAuth2AccessToken accessToken = PowerMockito.mock(OAuth2AccessToken.class);
		when(tokenServices.getAccessToken(authAuthentication)).thenReturn(accessToken);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		mockCXSContextHolder(httpRequest);
		OAuth2AccessToken output = customTokenGranter.grant(grantType,tokenRequest);
		Assert.assertNull(output);
	}
	
	private void mockCXSContextHolder(HttpServletRequest httpRequest){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
