package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({ LogoutTokenGranter.class })
public class LogoutTokenGranterUnitTest {

	private AuthorizationServerTokenServices tokenServices;
	private ClientDetailsService clientDetailsService;
	private OAuth2RequestFactory requestFactory;
	private String grantType;
	
	private LogoutTokenGranter logoutTokenGranter;
	
	@Before
	public void setup(){
		grantType = "Test";
		tokenServices = PowerMockito.mock(AuthorizationServerTokenServices.class);
		clientDetailsService = PowerMockito.mock(ClientDetailsService.class);
		requestFactory = PowerMockito.mock(OAuth2RequestFactory.class);
	}
	
	@Test
	public void grantMethodTest() throws Exception{
		ClientDetails clientDetails = PowerMockito.mock(ClientDetails.class);
		when(clientDetailsService.loadClientByClientId("clientId")).thenReturn(clientDetails);
		
		TokenRequest tokenRequest = PowerMockito.mock(TokenRequest.class);
		when(tokenRequest.getClientId()).thenReturn("clientId");
		Map<String, String> requestParameters = new HashMap<>();
		requestParameters.put(AuthConstant.ACCESS_TOKEN, "accessToken");
		when(tokenRequest.getRequestParameters()).thenReturn(requestParameters);
		
		ConsumerService consumerService = PowerMockito.mock(ConsumerService.class);
		when(consumerService.logout("accessToken")).thenReturn(true);
		PowerMockito.whenNew(ConsumerService.class).withAnyArguments().thenReturn(consumerService);
		
		OAuth2Request auth2Request = PowerMockito.mock(OAuth2Request.class);
		when(requestFactory.createOAuth2Request(clientDetails, tokenRequest)).thenReturn(auth2Request);
		
		OAuth2Authentication authAuthentication = PowerMockito.mock(OAuth2Authentication.class);
		PowerMockito.whenNew(OAuth2Authentication.class).withAnyArguments().thenReturn(authAuthentication);
		
		OAuth2AccessToken accessToken = PowerMockito.mock(OAuth2AccessToken.class);
		when(tokenServices.getAccessToken(authAuthentication)).thenReturn(accessToken);
		
		logoutTokenGranter = new LogoutTokenGranter(tokenServices, clientDetailsService, requestFactory, grantType);
		OAuth2AccessToken output = logoutTokenGranter.grant(grantType, tokenRequest);
		Assert.assertNull(output);
	}
	
}
