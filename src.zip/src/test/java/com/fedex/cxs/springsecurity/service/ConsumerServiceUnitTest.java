package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.cxs.calc.interfaces.accessgateway.LockDefinition;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.fcl.interfaces.FCLBoundary;
import com.fedex.cxs.cxsspringsecurity.process.BaseAuthServerTest;
import com.fedex.cxs.springsecurity.exceptions.InvalidAuthenticationException;
import com.fedex.cxs.springsecurity.exceptions.InvalidTokenException;
import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.properties.OauthProperties;
import com.fedex.cxs.springsecurity.vo.LoginInputVO;
import com.fedex.fcl.api.FCLAPI;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CommonAuthConfig.class,FCLBoundary.class,OauthProperties.class, FCLBoundary.class,
	ConsumerService.class})
@PowerMockIgnore("javax.management.*")
public class ConsumerServiceUnitTest extends BaseAuthServerTest{
	
	private FCLAPI fclAPI;
	private ConsumerService consumerService;
	private LoginInputVO loginInputVO;
	private HttpServletRequest httpRequest;
	
	@Before
	public void setup() throws Exception{
		mockCommonAuthConfig();
		loginInputVO = new LoginInputVO();
		loginInputVO.setUsername("user");
		loginInputVO.setPassword("password");
		httpRequest = PowerMockito.mock(HttpServletRequest.class);
		consumerService = new ConsumerService();
	}
	
	@Test
	public void loginTest() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "success");
		mockFCLBoundary(fclHashMap);
		Boolean result = consumerService.login(loginInputVO, httpRequest);
		Assert.assertTrue(result);
	}
	
	@Test
	public void loginTest1() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "success");
		fclHashMap.put("fdx_login", "#-901");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){
			
		}
	}
	
	@Test
	public void loginTest2() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "success");
		fclHashMap.put("fdx_login", "#-902");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){
			
		}
	}
	
	@Test
	public void loginTest3() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "success");
		fclHashMap.put("breachStatus", "success");
		fclHashMap.put("fdx_login", "#-903");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){
			
		}
	}
	
	@Test
	public void loginTestFail() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "fail");
		fclHashMap.put("fdx_login", "");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){
			
		}
	}
	
	@Test
	public void loginTestFail1() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "fail");
		fclHashMap.put("fdx_login", "123467345");
		fclHashMap.put("tcdate", "unknown");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){}
	}
	
	@Test
	public void loginTestFail2() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "fail");
		fclHashMap.put("fdx_login", "123467345");
		fclHashMap.put("mailflag", "1");
		mockFCLBoundary(fclHashMap);
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){}
	}
	
	@Test
	public void loginTestFail3() throws Exception{
		HashMap<String,String> fclHashMap = new HashMap<>();
		fclHashMap.put("status", "fail");
		fclHashMap.put("fdx_login", "123467345");
		mockFCLBoundary(fclHashMap);
		when(fclAPI.checkInfosecCompliance()).thenReturn("Test");
		try{
			consumerService.login(loginInputVO, httpRequest);
		}catch(InvalidAuthenticationException e){}
	}
	
	@Test
	public void logoutTest() throws Exception{
		ObjectMapper mapper = PowerMockito.mock(ObjectMapper.class);
		PowerMockito.whenNew(ObjectMapper.class).withAnyArguments().thenReturn(mapper);
		RequestorIdentity requestorIdentity = PowerMockito.mock(RequestorIdentity.class);
		Map<String, String> additionalIdentity = new HashMap<>();
		additionalIdentity.put("userName", "userName");
		when(requestorIdentity.getAdditionalIdentity()).thenReturn(additionalIdentity);
		when(mapper.readValue("{\"MSG\":\"Conventional Authentication Method\",\"CODE\":\"200\"}", RequestorIdentity.class)).thenReturn(requestorIdentity);
		
		consumerService = new ConsumerService();
		try{
			consumerService.logout("token");
		}catch(InvalidTokenException e){}	
	}
	
	private void mockFCLBoundary(HashMap<String, String> fclHashMap) throws Exception{
		fclAPI = PowerMockito.mock(FCLAPI.class);
		PowerMockito.whenNew(FCLAPI.class).withAnyArguments().thenReturn(fclAPI);
		
		HashMap<String, String> loginHashMap = new HashMap<String, String>();
		loginHashMap.put("userid", "user");
		loginHashMap.put("password", "password");
		loginHashMap.put("appname", "fclfsm");
		when(fclAPI.loginHashMap(loginHashMap)).thenReturn(fclHashMap);
	}
	
}
