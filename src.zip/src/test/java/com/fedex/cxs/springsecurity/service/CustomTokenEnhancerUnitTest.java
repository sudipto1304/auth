package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.rsa.crypto.KeyStoreKeyFactory;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.cxsspringsecurity.process.BaseAuthServerTest;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({ CXSContextHolder.class, CustomTokenEnhancer.class })
public class CustomTokenEnhancerUnitTest extends BaseAuthServerTest{

	private JwtAccessTokenConverter tokenConverter;
	private CustomTokenEnhancer customTokenEnhancer;
	private OAuth2Authentication authentication;
	
	@Before
	public void setup(){
		mockCommonAuthConfig();
		customTokenEnhancer = new CustomTokenEnhancer();
		tokenConverter = PowerMockito.mock(JwtAccessTokenConverter.class);
		ReflectionTestUtils.setField(customTokenEnhancer, "tokenConverter", tokenConverter);
	}
	
	@Test
	public void enhanceMethodTest() throws Exception{
		mockRequiredClasses();
		mockCXSContextHolder("");
		DefaultOAuth2AccessToken accessToken = PowerMockito.mock(DefaultOAuth2AccessToken.class);
		
		OAuth2AccessToken output = customTokenEnhancer.enhance(accessToken, authentication);
		Assert.assertNotNull(output);
	}
	
	@Test
	public void enhanceMethodTest1() throws Exception{
		mockRequiredClasses();
		mockCXSContextHolder("live");
		DefaultOAuth2AccessToken accessToken = PowerMockito.mock(DefaultOAuth2AccessToken.class);
		
		OAuth2AccessToken output = customTokenEnhancer.enhance(accessToken, authentication);
		Assert.assertNotNull(output);
	}
	
	private void mockRequiredClasses() throws Exception{
		KeyStoreKeyFactory keyStoreKeyFactory = PowerMockito.mock(KeyStoreKeyFactory.class);
		PowerMockito.whenNew(KeyStoreKeyFactory.class).withAnyArguments().thenReturn(keyStoreKeyFactory);
		ClassPathResource classPathResource = PowerMockito.mock(ClassPathResource.class);
		PowerMockito.whenNew(ClassPathResource.class).withAnyArguments().thenReturn(classPathResource);
		
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
	}
	
	private void mockCXSContextHolder(String appmode){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getHeader(AuthConstant.APPMODE)).thenReturn(appmode);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
