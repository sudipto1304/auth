package com.fedex.cxs.springsecurity.service;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.cxs.calc.security.fcl.FclIdentityProvider;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*"})
@PrepareForTest({ CXSContextHolder.class, RefreshTokenService.class })
public class RefreshTokenGranterUnitTest {

	private RefreshTokenService refreshTokenService;
	private BCryptPasswordEncoder encoder;
	
	private String refreshToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJMMlRFU1REQVRBMiIsInNjb3BlIjpbIkNYUyJdLCJhdGkiOiJkYTExZTUwYS0zZjE1LTRhNTctYWU4My03NmJhZTQ1MzU5MWQiLCJQYXlsb2FkIjp7ImNsaWVudElkZW50aXR5Ijp7ImNsaWVudEtleSI6Imw3NmJkMTQ0YzZmZjRhNGRiYjkzYzU0YjMyMTlkZGNjNTcifSwiYXV0aGVudGljYXRpb25SZWFsbSI6IkZDTCIsImFkZGl0aW9uYWxJZGVudGl0eSI6eyJ0aW1lU3RhbXAiOiIyNS1NYXItMjAyMCAxNzoyNjo0MyBFU1QiLCJVc2VyTmFtZSI6IkwyVEVTVERBVEEyIiwiYXBpbW9kZSI6bnVsbH0sInBlcnNvbmFUeXBlIjoiQ29uc3VtZXIiLCJjb25zdW1lcklkZW50aXR5Ijp7ImlkZW50aXR5IjoiN3g4MG1xRlBSTCIsInJhd0lkZW50aXR5Ijoic3NveGRldjEuYWIwZS44YmI3N2FhIiwibG9nZ2VkSW4iOnRydWV9fSwiZXhwIjoxNTg1MTkzMjAzLCJqdGkiOiI4NGU0MjgyOS03MjE5LTRlZjYtOWJlYi04MzEwYjU2YmRjYjkiLCJjbGllbnRfaWQiOiJsNzZiZDE0NGM2ZmY0YTRkYmI5M2M1NGIzMjE5ZGRjYzU3In0.eVjQT2hhOj2GuYf0fPMSMqJdhMebz85cQzKUeYBAqg4";
	
	@Before
	public void setup(){
		mockCXSContextHolder();
		encoder = PowerMockito.mock(BCryptPasswordEncoder.class);
		refreshTokenService = new RefreshTokenService();
		ReflectionTestUtils.setField(refreshTokenService, "encoder", encoder);
	}
	
	@Test
	public void loadUserByUsernameTest() throws Exception{
		FclIdentityProvider provider = PowerMockito.mock(FclIdentityProvider.class);
		when(provider.isAuthenticated()).thenReturn(true);
		PowerMockito.whenNew(FclIdentityProvider.class).withAnyArguments().thenReturn(provider);
		
		User users = PowerMockito.mock(User.class);
		PowerMockito.whenNew(User.class).withAnyArguments().thenReturn(users);
		
		UserDetails output = refreshTokenService.loadUserByUsername("userName");
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getParameter("refresh_token")).thenReturn(refreshToken);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
