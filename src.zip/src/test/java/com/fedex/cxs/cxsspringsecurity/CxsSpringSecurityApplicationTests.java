package com.fedex.cxs.cxsspringsecurity;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


public class CxsSpringSecurityApplicationTests {

	@Test
	@Ignore
	public void contextLoads() {
	}

}

