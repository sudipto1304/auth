package com.fedex.cxs.cxsspringsecurity.process;

import static org.mockito.Mockito.when;

import java.util.Properties;

import org.powermock.api.mockito.PowerMockito;
import org.powermock.reflect.Whitebox;

import com.fedex.cxs.springsecurity.properties.CommonAuthConfig;
import com.fedex.cxs.springsecurity.properties.OauthProperties;
import com.fedex.cxs.springsecurity.properties.OauthProperties.Key;

public class BaseAuthServerTest {
	
	public void mockCommonAuthConfig(){
		CommonAuthConfig commonAuthConfig = PowerMockito.mock(CommonAuthConfig.class);
		Whitebox.setInternalState(CommonAuthConfig.class, "instance",
				commonAuthConfig);
		OauthProperties authProperties = PowerMockito.mock(OauthProperties.class);
		when(authProperties.getUsrchostname()).thenReturn("USRC");
		when(authProperties.getSignKey()).thenReturn("secretKey");
		when(authProperties.isEnableEncryption()).thenReturn(false);
		
		Key mockKey = PowerMockito.mock(Key.class);
		when(mockKey.getKeystorePassCode()).thenReturn("keyStorePassCode");
		when(authProperties.getTestkey()).thenReturn(mockKey);
		when(authProperties.getProdkey()).thenReturn(mockKey);
		
		when(commonAuthConfig.getOauthProperties()).thenReturn(authProperties);
		
		Properties properties = PowerMockito.mock(Properties.class);
		when(commonAuthConfig.getURIConfigProperties()).thenReturn(properties);
	}
	
}
