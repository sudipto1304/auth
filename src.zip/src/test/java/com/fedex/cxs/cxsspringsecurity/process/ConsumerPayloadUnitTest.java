package com.fedex.cxs.cxsspringsecurity.process;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.ConsumerPayload;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({CXSContextHolder.class})
public class ConsumerPayloadUnitTest {

	private ConsumerPayload process;
	private OAuth2Authentication authentication;
	
	@Test
	public void processSuccessfulHttpRequest(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		Cookie cookie = new Cookie("fdx_login","Test");
		Cookie cookie1 = new Cookie("fcl_uuid","Test");
		Cookie[] cookies = new Cookie[]{cookie,cookie1};
		when(httpRequest.getCookies()).thenReturn(cookies);
		
		mockCXSContextHolder(httpRequest,null);
		
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
		process = new ConsumerPayload();
		RequestorIdentity output = process.getRequesterIdentity(authentication);
		Assert.assertNotNull(output);
	}
	
	@Test
	public void processSuccessfulFCLHashMap(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		Map<String, String> fclHashMap = new HashMap<>();
		fclHashMap.put("uuid", "Test");
		fclHashMap.put("fdx_login", "Test");
		mockCXSContextHolder(httpRequest,fclHashMap);
		
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
		when(authentication.getUserAuthentication()).thenReturn(authentication);
		process = new ConsumerPayload();
		RequestorIdentity output = process.getRequesterIdentity(authentication);
		Assert.assertNotNull(output);
	}
	
	@Test
	public void processSuccessfulNonLoggedIn(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		mockCXSContextHolder(httpRequest,null);
		
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
		process = new ConsumerPayload();
		RequestorIdentity output = process.getRequesterIdentity(authentication);
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(HttpServletRequest httpRequest,Map<String, String> fclHashMap){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(cxsContext.getProperty(AuthConstant.FCL_MAP)).thenReturn(fclHashMap);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
