package com.fedex.cxs.cxsspringsecurity.process;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import com.fedex.cxs.calc.security.IdentityProvider;
import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.calc.security.wstm.authn.WstmAuthenticationProviderFactory;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.WSTMPayload;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({CXSContextHolder.class, WstmAuthenticationProviderFactory.class, WSTMPayload.class})
public class WSTMPayloadUnitTest {
	
	private WSTMPayload process;
	private OAuth2Authentication authentication;

	@Mock
	private HttpServletRequest httpRequest; 
	@Mock
	private HttpServletResponse response;
	
	@Before
	public void setup(){
		mockCXSContextHolder();
	}
	
	@Test
	public void processSuccessful() throws Exception{
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
		WstmAuthenticationProviderFactory authProvider = PowerMockito.mock(WstmAuthenticationProviderFactory.class);
		PowerMockito.whenNew(WstmAuthenticationProviderFactory.class).withAnyArguments().thenReturn(authProvider);

		IdentityProvider identityProvider = PowerMockito.mock(IdentityProvider.class);
		when(identityProvider.getIdentity()).thenReturn(new RequestorIdentity());
		when(authProvider.getIdentityProvider(httpRequest, response)).thenReturn(identityProvider);
		
		process = new WSTMPayload(httpRequest,response);
		RequestorIdentity output = process.getRequesterIdentity(authentication);
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
