package com.fedex.cxs.cxsspringsecurity.process;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.springsecurity.process.EmptyPersonaPayload;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.management.*")
public class EmptyPersonaPayloadUnitTest {

	private EmptyPersonaPayload process;
	
	@Test
	public void processSuccessful(){
		process = new EmptyPersonaPayload();
		RequestorIdentity output = process.getRequesterIdentity(null);
		Assert.assertNotNull(output);
	}
	
}
