package com.fedex.cxs.cxsspringsecurity.process;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import com.fedex.cxs.calc.security.RequestorIdentity;
import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.B2BPayload;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({CXSContextHolder.class})
public class B2BPayloadUnitTest extends BaseAuthServerTest {

	private B2BPayload process;
	private OAuth2Authentication authentication;
	
	@Before
	public void setup(){
		mockCXSContextHolder();
	}
	
	@Test
	public void processSuccessfulTest(){
		authentication = PowerMockito.mock(OAuth2Authentication.class);
		OAuth2Request oauthRequest = PowerMockito.mock(OAuth2Request.class);
		when(authentication.getOAuth2Request()).thenReturn(oauthRequest);
		process = new B2BPayload();
		RequestorIdentity output = process.getRequesterIdentity(authentication);
		Assert.assertNotNull(output);
	}
	
	private void mockCXSContextHolder(){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
