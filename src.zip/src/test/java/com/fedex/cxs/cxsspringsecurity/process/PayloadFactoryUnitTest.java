package com.fedex.cxs.cxsspringsecurity.process;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.fedex.cxs.core.context.CXSContextHolder;
import com.fedex.cxs.springsecurity.process.B2BPayload;
import com.fedex.cxs.springsecurity.process.CSPPayload;
import com.fedex.cxs.springsecurity.process.ConsumerPayload;
import com.fedex.cxs.springsecurity.process.EmployeePayload;
import com.fedex.cxs.springsecurity.process.EmptyPersonaPayload;
import com.fedex.cxs.springsecurity.process.PayloadFactory;
import com.fedex.cxs.springsecurity.process.WSTMPayload;
import com.fedex.cxs.springsecurity.util.AuthConstant;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.management.*","javax.security.auth.*"})
@PrepareForTest({CXSContextHolder.class})
public class PayloadFactoryUnitTest {

	@Test
	public void getCSP(){
		CSPPayload cspPayload = (CSPPayload)PayloadFactory.getInstance(AuthConstant.CSP_CREDENTIALS);
		Assert.assertNotNull(cspPayload);
	}
	
	@Test
	public void getConsumer(){
		ConsumerPayload consumerPayload = (ConsumerPayload)PayloadFactory.getInstance(AuthConstant.GRANT_TYPE_PASSWORD);
		Assert.assertNotNull(consumerPayload);
	}
	
	@Test
	public void getEmployee(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getHeader(AuthConstant.WSSO_HEADER)).thenReturn("OBLIX_UID");
		mockCXSContextHolder(httpRequest);
		
		EmployeePayload employeePayload = (EmployeePayload)PayloadFactory.getInstance(AuthConstant.CLIENT_CREDENTIALS);
		Assert.assertNotNull(employeePayload);
	}
	
	@Test
	public void getWSTM(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getHeader(AuthConstant.WSTM_HEADER)).thenReturn("FDX_UUID");
		mockCXSContextHolder(httpRequest);
		
		WSTMPayload wstmPayload = (WSTMPayload)PayloadFactory.getInstance(AuthConstant.CLIENT_CREDENTIALS);
		Assert.assertNotNull(wstmPayload);
	}
	
	@Test
	public void getB2B(){
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		mockCXSContextHolder(httpRequest);
		
		B2BPayload b2bPayload = (B2BPayload)PayloadFactory.getInstance(AuthConstant.CLIENT_CREDENTIALS);
		Assert.assertNotNull(b2bPayload);
	}
	
	@Test
	public void getEmpty(){
		EmptyPersonaPayload emptyPayload = (EmptyPersonaPayload)PayloadFactory.getInstance("");
		Assert.assertNotNull(emptyPayload);
	}
	
	private void mockCXSContextHolder(HttpServletRequest httpRequest){
		PowerMockito.mockStatic(CXSContextHolder.class);
		CXSContextHolder cxsContext = PowerMockito.mock(CXSContextHolder.class);
		when(cxsContext.getProperty(AuthConstant.HTTP_REQUEST)).thenReturn(httpRequest);
		when(CXSContextHolder.getContext()).thenReturn(cxsContext);
	}
	
}
