package com.fedex.cxs.calc.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ContentTypeUtil  {

	private static final String PDF_CONTENT_TYPE = "application/pdf";
	private static final String PNG_CONTENT_TYPE = "image/png";
	private static final String HTML_CONTENT_TYPE = "text/html";

	private static final byte[] PNG_MAGIC_NUMBER = { (byte) 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a };
	private static final byte[] PDF_MAGIC_NUMBER = "%PDF".getBytes();
	private static final byte[] EMPTY_MAGIC_NUMBER = new byte[0];

	private static final ContentMapperInfo HTML_MAPPER = new ContentMapperInfo("OTHER", HTML_CONTENT_TYPE, EMPTY_MAGIC_NUMBER);

	private static final List<ContentMapperInfo> contentMappers = new ArrayList<ContentMapperInfo>();

	private static final Logger logger = LoggerFactory.getLogger(ContentTypeUtil.class);
	
	static {
		contentMappers.add(new ContentMapperInfo("PDF", PDF_CONTENT_TYPE, PDF_MAGIC_NUMBER));
		contentMappers.add(new ContentMapperInfo("PNG", PNG_CONTENT_TYPE, PNG_MAGIC_NUMBER));
		// the empty one will always match
		contentMappers.add(HTML_MAPPER);
	}

	private ContentTypeUtil() {
		// private constructor
	}

	/**
	 * Based on the content (typically the bytes from a file), figure out what type of content it is. (For example,
	 * "application/pdf" is returned if the content is a PDF file.)<br>
	 * 
	 * Currently will handle PNG, PDF. All else returns "text/html".
	 * 
	 * @param content
	 *            The bytes in the file. (These will not be changed.)
	 * @return The media type (mime type) of the content.
	 */
	public static String mediaType(byte[] content) {
		ContentMapperInfo mapper = findMapper(content);
		debugS("mediaType(): " + mapper.getName() + " content. length:[" + content.length + "]");
		return mapper.getContentType();
	}

	/**
	 * Based on the content (typically the bytes from a file), figure out what type of content it is. (For example,
	 * "PDF" is returned if the content is a PDF file.)<br>
	 * 
	 * Currently will handle PNG, PDF. All else returns OTHER.
	 * 
	 * @param content
	 *            The bytes in the file. (These will not be changed.)
	 * @return The name of the content type.
	 */
	public static String contentTypeName(final byte[] content) {
		ContentMapperInfo mapper = findMapper(content);
		debugS("contentTypeName(): " + mapper.getName() + " content. length:[" + content.length + "]");
		return mapper.getName();
	}

	private static ContentMapperInfo findMapper(final byte[] content) {
		for (ContentMapperInfo mapper : contentMappers) {
			if (mapper.match(content)) {
				return mapper;
			}
		}
		return HTML_MAPPER;

	}

	private static void debugS(String msg) {
			logger.debug(msg);
	}

	private static class ContentMapperInfo {
		private String name;
		private byte[] magicNumber;
		private String contentType;

		public ContentMapperInfo(String aName, String aContentType, byte[] aMagicNumber) {
			name = aName;
			magicNumber = aMagicNumber;
			contentType = aContentType;
		}

		/**
		 * Test this mapper info against the supplied content.
		 * 
		 * @param content
		 *            test against this. Do the first few bytes match?
		 * @return true if they match
		 */
		public boolean match(byte[] content) {
			if (content.length < magicNumber.length) {
				// Can't match if content is too short
				return false;
			}
			for (int i = 0; i < magicNumber.length; ++i) {
				if (magicNumber[i] != content[i]) {
					return false;
				}
			}
			return true;
		}

		public String getName() {
			return name;
		}

		public String getContentType() {
			return contentType;
		}

		@Override
		public String toString() {
			return name + ": " + contentType + " \"" + magicNumber.toString() + "\"";
		}
	}

}