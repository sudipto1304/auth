package com.fedex.cxs.calc.util;

public final class MaskUtil {
	
	private MaskUtil() {
		
	}

	public static String maskAccountNumber(String accountNumber) {
		if (accountNumber != null) {
			StringBuilder sb = new StringBuilder();
			int len = accountNumber.length();
			for (int i = 0; i < len - 3; i++) {
				sb.append("*");
			}
			sb.append(accountNumber.substring(len - 3, len));
			return sb.toString();
		}
		return accountNumber;
	}

	public static String maskAccountNumber(String nickname, String accountNumber) {
		if (accountNumber != null) {
			StringBuilder sb = new StringBuilder();
			sb.append(nickname);
			sb.append('-');
			int col = accountNumber.length() - 3;
			if (col < 0) {
				col = 0;
			}
			sb.append(accountNumber.substring(col));
			return sb.toString();
		}
		return accountNumber;
	}
	
	public static String maskCreditCard(String creditCardNumber) {
		if (creditCardNumber != null) {
			StringBuilder sb = new StringBuilder();
			int len = creditCardNumber.length();
			for (int i = 0; i < len - 3; i++) {
				sb.append("*");
			}
			sb.append(creditCardNumber.substring(len - 4, len));
			return sb.toString();
		}
		return creditCardNumber;
	}
}
