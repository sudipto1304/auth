package com.fedex.cxs.calc.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.fedex.cxs.calc.config.CommonAppConfig;
import com.fedex.cxs.calc.plcy.vo.SoftwareDetailsGridRowData;
import com.fedex.cxs.calc.plcy.vo.SoftwareDetailsVO;
import com.fedex.nxgen.plcy.v4.ientities.Policy;
import com.fedex.nxgen.plcy.v4.ientities.PolicyAttribute;
import com.fedex.nxgen.plcy.v4.ientities.PolicyCondition;
import com.fedex.nxgen.plcy.v4.ientities.PolicyGridManifestFile;
import com.fedex.nxgen.plcy.v4.util.PlcyUtil;
import com.fedex.nxgen.plcy.v4.util.dataUtil.DecodedManifestData;
import com.fedex.nxgen.plcy.v4.util.decoder.PolicyGridManifestDecoder;

@Component
public class PolicyGridUtil {
	public SoftwareDetailsVO loadSoftwareRelatedAttributes() {
		return loadAndDecodeManifestFile(CommonAppConfig.getInstance().getSoftwareDetailsPolicyGridURL());
	}

	private SoftwareDetailsVO loadAndDecodeManifestFile(String softwareDetailsPolicyGridURL) {
		SoftwareDetailsVO softwareDetailsVO = new SoftwareDetailsVO();
		try {
			PolicyGridManifestFile manifile = getPolicyManifestFile(new java.net.URL(softwareDetailsPolicyGridURL));
			DecodedManifestData decodedManifestData = PolicyGridManifestDecoder.decodeFile(manifile);
			softwareDetailsVO = getSoftwareDetailsVOFromdecodedManifestData(decodedManifestData);
			return softwareDetailsVO;
		} catch (Exception e) {
			try {
				Resource resource = new ClassPathResource("PolicyGridEncodedData.txt");
				InputStream is = resource.getInputStream();
				BufferedReader reader = new BufferedReader(new InputStreamReader(is));
				PolicyGridManifestFile manifestFile = null;
				Map<String, Object> map = PlcyUtil.parseManifestFile(reader);
				manifestFile = (PolicyGridManifestFile) map.get("MANIFEST");
				DecodedManifestData decodedManifestData = PolicyGridManifestDecoder.decodeFile(manifestFile);
				softwareDetailsVO = getSoftwareDetailsVOFromdecodedManifestData(decodedManifestData);
				return softwareDetailsVO;
			} catch (IOException e1) {

			}
		}
		return softwareDetailsVO;

	}

	private SoftwareDetailsVO getSoftwareDetailsVOFromdecodedManifestData(DecodedManifestData decodedManifestData) {
		SoftwareDetailsVO softwareDetailsVO = new SoftwareDetailsVO();
		Map<Integer, SoftwareDetailsGridRowData> softwareDetailsGridMapData = new HashMap<Integer, SoftwareDetailsGridRowData>();
		SoftwareDetailsGridRowData softwareDetailsGridRowData = null;
		for (int i = 0; i < decodedManifestData.getPolicyGrid().getPolicies().length; i++) {
			softwareDetailsGridRowData = new SoftwareDetailsGridRowData();
			Policy policy = decodedManifestData.getPolicyGrid().getPolicies()[i];
			PolicyCondition[] policyCondition = policy.getConditions();
			softwareDetailsGridRowData.setApiPortalGroup(policyCondition[0].getValues()[0]);
			softwareDetailsGridRowData.setApiGroupVersion(policyCondition[1].getValues()[0]);
			softwareDetailsGridRowData.setClientId(policyCondition[2].getValues()[0]);
			PolicyAttribute[] policyAttribute = policy.getAttributes();
			softwareDetailsGridRowData.setSoftwareId(policyAttribute[0].getValues()[0]);
			softwareDetailsGridRowData.setSoftwareVersion(policyAttribute[1].getValues()[0]);
			softwareDetailsGridMapData.put(new Integer(i), softwareDetailsGridRowData);
			softwareDetailsVO.setSoftwareDetailsGridRowData(softwareDetailsGridMapData);
		}
		return softwareDetailsVO;
	}

	public PolicyGridManifestFile getPolicyManifestFile(java.net.URL policyGridFile) throws IOException {
		PolicyGridManifestFile manifestFile = null;
		java.net.URLConnection con = policyGridFile.openConnection();
		InputStream in = con.getInputStream();
		InputStreamReader reader = new InputStreamReader(in);
		Map<String, Object> map = PlcyUtil.parseManifestFile(reader);
		manifestFile = (PolicyGridManifestFile) map.get("MANIFEST");
		return manifestFile;
	}

	public String getProperty(String propertyName) {
		Properties prop = new Properties();
		try {
			InputStream is = RetrieveSoftwareIdentifierUtil.class.getClassLoader()
					.getResourceAsStream("policygrid.properties");
			prop.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop.getProperty(propertyName);
	}
}
