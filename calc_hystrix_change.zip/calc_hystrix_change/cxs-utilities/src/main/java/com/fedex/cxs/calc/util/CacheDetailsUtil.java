package com.fedex.cxs.calc.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.fedex.cxs.calc.interfaces.plcy.PlcyServiceSoftwareDetailsTransaction;
import com.fedex.cxs.calc.plcy.vo.SoftwareDetailsVO;

@Component
public class CacheDetailsUtil {
	
	private static final Logger Log = LoggerFactory.getLogger(CacheDetailsUtil.class);

	@Autowired
	private PlcyServiceSoftwareDetailsTransaction plcyServiceSoftwareDetailsTransaction;

	@Cacheable(value = "SoftwareDetailsGridRegion", key = "#SoftwareDetailsKey", cacheManager = "ehcacheManager")
	public SoftwareDetailsVO getSoftwareAttributes(String SoftwareDetailsKey) {
		Log.debug("Caching PolicyGrid Modernized FedEx APIs");
		SoftwareDetailsVO softwareDetailsVO = plcyServiceSoftwareDetailsTransaction.getSoftwareDetailsFromPlcyService();
		return softwareDetailsVO;
	}

}
