package com.fedex.cxs.calc.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ListFileLoader {
	
	private static final Logger logger = LoggerFactory.getLogger(ListFileLoader.class);

	/**
	 * Returns a List object parsed from the specified fully-qualified filename,
	 * if file not found, then a non-null
	 *
	 * @param fileName
	 *            String
	 * @return Properties
	 */
	public List<String> getListFromFile(String fileName) {
		List<String> lines = new ArrayList<String>();

		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		try {
			fileReader = new FileReader(fileName);
			bufferedReader = new BufferedReader(fileReader);
			String line = null;

			while ((line = bufferedReader.readLine()) != null) {
				lines.add(line);
			}

			bufferedReader.close();
		} catch (IOException ioe) {
			logger.error("Exception loading ArrayList file <" + fileName + ">", ioe);
		} finally {
			// ALWAYS close the file whether an exception was thrown or not.
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			} catch (IOException ioe) {
				logger.error("Exception closing ArrayList file <" + fileName + ">", ioe);
			}
		}

		if (lines.isEmpty()) {
			logger.error("Attempted to load ArrayList file <" + fileName + ">, but no values found!");
		}
		return lines;
	}
}
