package com.fedex.cxs.calc.interfaces.plcy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.cxs.calc.plcy.vo.SoftwareDetailsVO;
import com.fedex.cxs.calc.util.PolicyGridUtil;
@Component
public class PlcyServiceSoftwareDetailsTransaction {
	@Autowired
	private PolicyGridUtil policyGridUtil;
	public PlcyServiceSoftwareDetailsTransaction(){
		
	}
	public SoftwareDetailsVO getSoftwareDetailsFromPlcyService() {
		return policyGridUtil.loadSoftwareRelatedAttributes();
		
	}
}
