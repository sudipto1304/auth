package com.fedex.cxs.calc.util;

import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fedex.cxs.calc.config.CommonAppConfig;
import com.fedex.cxs.calc.exception.CALSystemException;
import com.fedex.cxs.calc.util.StringUtil;

/**
 * Class provides Data encryption decryption using Password based encryption
 * algorithm (PBE). This is a single instance class and uses a unique secret key
 * specification.
 * 
 * @see {@link javax.crypto.spec.PBEKeySpec}
 * @author 853733
 */
public class SecureKeyGenerator {

	private static final SecureKeyGenerator instance = new SecureKeyGenerator();
	private static byte[] salt;
	private static String passphrase;
	private static final int iterationCount = 1024;
	private static final int keyLength = 256;
	 /** key algorithm */
    private static final String KEY_ALGORITHM = "PBE";

    private static final Logger logger = LoggerFactory.getLogger(SecureKeyGenerator.class);
    
	private SecureKeyGenerator() {
		// singleton
	}

	static  {
		try {
			Properties p = CommonAppConfig.getInstance().getSecureKeyGenProperties();
			salt = StringUtil.hexStringToByteArray((String) p.get("Salt"));
			passphrase = (String) p.get("Passphrase");
	    } catch (Exception e) {
	        logger.warn("Issue loading Salt & Passphrase", e);
	    }
		
	}

	public static SecureKeyGenerator getInstance() {
		return instance;
	}

	/**
	 * Encrypts a given String(i.e account number).
	 * If decoupled, then return the supplied value(no encryption performed).
	 * @param stringToEncrypt
	 * 
	 * @return Encrypted String - The key
	 * @throws Exception
	 */
	public String encrypt(String stringToEncrypt) throws CALSystemException {
		if (StringUtils.isBlank(stringToEncrypt)) {
			return "";
		}
		try {
			
			byte[] encrypted = getCipher(Cipher.ENCRYPT_MODE).doFinal((stringToEncrypt).getBytes());
			return StringUtil.asHex(encrypted); 
		} catch (Exception e) {
			logger.warn("Error encrypting key", e);
			throw new CALSystemException("KEYGENERATION.FAILURE", "Encryption failure");
		}
	}
	
	/**
	 * Decrypts the encrypted string. 
	 * If decoupled,then return the supplied key(assumed that it was not encrypted)
	 * 
	 * @param encryptedKey
	 * 
	 * @return Decrypted String (i.e Account number)
	 * @throws Exception
	 */
	public String decrypt(String encryptedKey) throws CALSystemException {
		try {
			byte bdecrypt[] = getCipher(Cipher.DECRYPT_MODE).doFinal(StringUtil.hexStringToByteArray(encryptedKey));
			return new String(bdecrypt);
		} catch (Exception e) {
			logger.warn("Error decrypting key", e);
			throw new CALSystemException("KEYGENERATION.FAILURE", "Decryption failure");
		}
	}
	
	private Cipher getCipher(int mode) throws Exception{
		PBEKeySpec keySpec = getPBEKeySpec();
		SecretKey key = generateSecretKey(keySpec);
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(mode, key, getParameterSpecification(keySpec));
		return cipher;
	}

	/**
	 * Returns a Password Based Encryption KeySpec
	 *  
	 * @return
	 */
	private static PBEKeySpec getPBEKeySpec() {
		PBEKeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, keyLength);
		return keySpec;
	}
	
	/**
	 * The heart of the class is in here. Responsible for generating the secret
	 * key specification of encryption / decryption.
	 * 
	 * @param keySpec
	 * @return
	 */
	private static SecretKey generateSecretKey(PBEKeySpec keySpec) throws Exception{
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);
		SecretKey key = keyFactory.generateSecret(keySpec);
		return key;
	}

	/**
	 * Returns the set of parameters used for PBE.
	 * 
	 * @param keySpec PEBKeySpec
	 * @return
	 */
	private static PBEParameterSpec getParameterSpecification(PBEKeySpec keySpec) {
		return new PBEParameterSpec(keySpec.getSalt(), keySpec.getIterationCount());
	}
}
