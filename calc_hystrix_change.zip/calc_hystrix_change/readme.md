# **cxs-cmac-security**

#### <span style="color:red">Latest Version 3.7.0</span> 

##### Version 3.7.0

### Release Note
* Consume **cxs-security-3.7.0**
* Introduced new CMAC account validation and key validation call
* client data is available inside ClientIdentity
* <span style="color:red"> Breaking changes has been introduced </span> 

# **cxs-logging**

#### <span style="color:red">Latest Version 3.7.0</span> 

##### Version 3.7.0

### Release Note
* Custom Layout created as ```CXSPatternLayout```
* ```CXSPatternLayout``` could be used in logback encoder for JSON format log print as well as PII and PCI data masking
* masking pattern can be configured in ```application.yml```
* Refer CALC 3.7 adoption document for details

# **cxs-security**

#### <span style="color:red">Latest Version 3.7.0</span> 

##### Version 3.7.0

### Release Note
* Change ``RequestorIdentity`` object
* ``getIdentity, setIdentity, getRawIdentity, setRawIdentity`` methods are deprecated
* Added ``ConsumerIdentity`` and ``ClientIdentity``
* Added new ``AuthenticationRealm`` as **CMAC**
* Please find alternatives for deprecated methods

## Alternatives


```java
getIdentity() ---> getConsumerIdentity().getIdentity();
setIdentity(String identity) ---> getConsumerIdentity().setIdentity(String identity);
getRawIdentity() ---> getConsumerIdentity().getRawIdentity();
setRawIdentity(String rawIdentity) ---> getConsumerIdentity().setRawIdentity(String rawIdentity);
```

## New ClientIdentity fields

```java
private String clientKey;
private String applicationId;
private String childKey;
private String childSecret;
```