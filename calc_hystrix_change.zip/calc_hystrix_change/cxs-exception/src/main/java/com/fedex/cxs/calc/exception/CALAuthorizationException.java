package com.fedex.cxs.calc.exception;

import java.util.List;

public class CALAuthorizationException extends CALValidationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	/**
	 * @param cxsError
	 * @param t
	 */
	public CALAuthorizationException(CXSError cxsError, Throwable t) {
		super(cxsError, t);
		
	}

	/**
	 * @param cxsError
	 */
	public CALAuthorizationException(CXSError cxsError) {
		super(cxsError);
		
	}

	/**
	 * @param cxsErrors
	 * @param dummy
	 */
	public CALAuthorizationException(List<CXSError> cxsErrors) {
		super(cxsErrors);
		
	}
	
	/**
	 * @param cxsErrors
	 * @param dummy
	 */
	public CALAuthorizationException(List<CXSError> cxsErrors,Throwable t) {
		super(cxsErrors,t);
		
	}



}
