package com.fedex.cxs.calc.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * New Error domain class to represent error data in CXS 3.0
 * 
 * @author 5145270
 *
 */
@XmlRootElement(name = "CXSError")
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name = "CXSError", propOrder = { "code", "message" })
public class CXSError implements Serializable {

	private static final long serialVersionUID = 1L;
	private String code;
	private String message;

	private transient List<Parameter> parameterList;

	public CXSError() {
	}

	/**
	 * @param code
	 * @param context
	 *
	 */
	public CXSError(String code) {
		this.code = code;
	}

	/**
	 * @param code
	 * @param context
	 *
	 */
	public CXSError(String code,String message) {
		this.code = code;
		this.message = message;
	}

	/**
	 * @param code
	 * @param parameterList
	 */
	public CXSError(String code, List<Parameter> parameterList) {
		this.code = code;
		this.parameterList = parameterList;
	}
	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


	public List<Parameter> getParameterList() {
		return parameterList;
	}

	public void setParameterList(List<Parameter> parameterList) {
		this.parameterList = parameterList;
	}

}
