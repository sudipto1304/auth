/**
 * 
 */
package com.fedex.cxs.calc.exception;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

/**
 * @author 5145270
 *
 */
@XmlType(name = "Parameter", namespace = "http://www.fedex.com/cxs/vo")
public class Parameter implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String key;
	
	private String value;

	
	public Parameter(){
		
	}
	
	/**
	 * @param key
	 * @param value
	 */
	public Parameter(String key, String value) {
		this.key = key;
		this.value = value;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
}
