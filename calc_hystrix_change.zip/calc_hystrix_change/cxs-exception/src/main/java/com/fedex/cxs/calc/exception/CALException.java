package com.fedex.cxs.calc.exception;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;


public abstract class CALException extends Exception {

	private static final long serialVersionUID = 1L;
	

	/**
	 * @param cxsErrors
	 */
	public CALException(List<CXSError> cxsErrors) {
		this.cxsErrors = cxsErrors;
	}

	protected CALException(CXSError theError, Throwable t) {
		super(t);
		addCXSError(theError);
	}
	
	// added for cxs 3.0
	private List<CXSError> cxsErrors = new ArrayList<CXSError>();
	
	public CALException() {
		super();
	}
	
	public CALException(Throwable t) {
		super(t);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}



	/**
	 * added for cxs 3.0
	 * 
	 * @param acxsErrors
	 */
	public void addCXSErrors(List<CXSError> acxsErrors) {
		if (this.cxsErrors == null) {
			cxsErrors = new ArrayList<CXSError>();
		}
		cxsErrors.addAll(acxsErrors);
	}

	/**
	 * added for cxs 3.0
	 * 
	 * @param acxsError
	 */
	public void addCXSError(CXSError acxsError) {
		if (this.cxsErrors == null) {
			cxsErrors = new ArrayList<CXSError>();
		}
		cxsErrors.add(acxsError);
	}

	/**
	 * @return the cxsErrors
	 */
	public List<CXSError> getCxsErrors() {
		return cxsErrors;
	}

	/**
	 * @param cxsErrors
	 *            the cxsErrors to set
	 */
	public void setCxsErrors(List<CXSError> cxsErrors) {
		this.cxsErrors = cxsErrors;
	}

}
