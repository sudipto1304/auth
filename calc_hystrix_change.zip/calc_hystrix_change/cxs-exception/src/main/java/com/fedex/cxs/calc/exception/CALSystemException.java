package com.fedex.cxs.calc.exception;

import java.util.ArrayList;
import java.util.List;

public class CALSystemException extends CALException {

	private static final long serialVersionUID = 1L;

	private List<CXSError> cxsSystemErrors = new ArrayList<CXSError>();

	public CALSystemException(String code, String message) {
		addDefaultCXSError();
	}

	/**
	 * @param e
	 */
	public CALSystemException(Throwable t) {
		super(t);// preserve exception trace
		// backward compatibility for 2.6

		

		// add default cxs error
		addDefaultCXSError();
	}

	/**
	 * Constructor to be used for any new end points in 3.0
	 * 
	 * @param cxsError
	 */
	public CALSystemException(CXSError cxsError) {
		super();
		// add default cxs error
		addDefaultCXSError();
		this.addCXSSystemError(cxsError);
	}

	/**
	 * Constructor to be used for any new end points in 3.0
	 * 
	 * @param cxsError
	 */
	public CALSystemException(CXSError cxsError, Throwable t) {
		super(t);

		
		// add default cxs error
		addDefaultCXSError();
		this.addCXSSystemError(cxsError);
	}

	/**
	 * Constructor to be used for any new end points in 3.0
	 * 
	 * @param cxsErrors
	 */
	public CALSystemException(List<CXSError> cxsErrors) {
		super();
		// add default cxs error
		addDefaultCXSError();
		this.addCXSSystemErrors(cxsErrors);
	}

	public boolean isSystemException() {
		return true;
	}

	private void addDefaultCXSError() {
		this.addCXSError(new CXSError("SYSTEM.UNEXPECTED.ERROR"));
	}

	/**
	 * @return the cxsSystemErrors
	 */
	public List<CXSError> getCxsSystemErrors() {
		return cxsSystemErrors;
	}

	/**
	 * @param cxsSystemErrors
	 *            the cxsSystemErrors to set
	 */
	public void setCxsSystemErrors(List<CXSError> cxsSystemErrors) {
		this.cxsSystemErrors = cxsSystemErrors;
	}

	public void addCXSSystemErrors(List<CXSError> acxsErrors) {
		if (this.cxsSystemErrors == null) {
			cxsSystemErrors = new ArrayList<CXSError>();
		}
		cxsSystemErrors.addAll(acxsErrors);
	}

	/**
	 * added for cxs 3.0
	 * 
	 * @param acxsError
	 */
	public void addCXSSystemError(CXSError acxsError) {
		if (this.cxsSystemErrors == null) {
			cxsSystemErrors = new ArrayList<CXSError>();
		}
		cxsSystemErrors.add(acxsError);
	}

}
