package com.fedex.cxs.calc.exception;

import java.io.Serializable;
import java.util.List;

@Deprecated
public class CXSAlert implements Serializable {

	private static final long serialVersionUID = 1L;
	private String code;
	private String message;
	
	private ALERTTYPE alertType;
	private transient List<Parameter> parameterList;

	public CXSAlert(){
		
	}	
	
	/**
	 * @param code
	 * @param message
	 * @param alertType
	 */
	public CXSAlert(String code, String message, ALERTTYPE alertType) {
		this.code = code;
		this.message = message;
		this.alertType = alertType;
	}
	
	/**
	 * @param code
	 * @param parameterList
	 */
	public CXSAlert(String code, List<Parameter> parameterList) {
		this.code = code;
		this.parameterList = parameterList;
	}
	
	/**
	 * @param code
	 * @param message
	 * @param alertType
	 */
	public CXSAlert(String code, String message, ALERTTYPE alertType, List<Parameter> parameterList) {
		this(code, message, alertType);
		this.parameterList = parameterList;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the alertType
	 */
	public ALERTTYPE getAlertType() {
		return alertType;
	}

	/**
	 * @param alertType the alertType to set
	 */
	public void setAlertType(ALERTTYPE alertType) {
		this.alertType = alertType;
	}
	
	/**
	 * @return the parameterList
	 */
	public List<Parameter> getParameterList() {
		return parameterList;
	}

	/**
	 * @param parameterList the parameterList to set
	 */
	public void setParameterList(List<Parameter> parameterList) {
		this.parameterList = parameterList;
	}
	
}
