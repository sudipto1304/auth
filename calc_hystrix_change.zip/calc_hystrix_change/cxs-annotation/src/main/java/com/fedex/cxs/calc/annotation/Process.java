package com.fedex.cxs.calc.annotation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fedex.cxs.calc.annotation.util.ClassUtil;

public class Process {

	private static final Logger LOGGER = LoggerFactory.getLogger(Process.class);
	public static final void main(String[] args) {

		if (args.length != 3) {
			LOGGER.info("Arguments:  [CAL name] [output PBD file location] [classes directory]");//NOPMD
			System.exit(1);
		}
		else {
			try {
				FileWriter fstream = new FileWriter(args[1]);
				BufferedWriter out = new BufferedWriter(fstream);
		    
		        
		    
		        ArrayList<Class> classList = ClassUtil.getClassesFromDirectory(new File(args[2]),null);
		        for (Class aClass : classList) {
					for (Method aMethod : aClass.getDeclaredMethods()) {
						if ( aMethod.isAnnotationPresent(Wily.class) ) {
							LOGGER.info(aMethod.getDeclaringClass().getName() + "." + aMethod.getName() + "()");//NOPMD
							StringBuilder lineOne = new StringBuilder();
							lineOne.append("TraceOneMethodofClass: ");
							lineOne.append(aClass.getName() +" "+aMethod.getName()+" ");
							lineOne.append("MethodTimer \""+args[0]+"_custom|");
							lineOne.append(aClass.getSimpleName()+"|"+aMethod.getName());
							lineOne.append(":Average Response Time(ms)\"");
							lineOne.append("\n");
							out.write(lineOne.toString());
							
							StringBuilder lineTwo = new StringBuilder();
							lineTwo.append("TraceOneMethodofClass: ");
							lineTwo.append(aClass.getName() +" "+aMethod.getName()+" ");
							lineTwo.append("PerIntervalCounter \""+args[0]+"_custom|");
							lineTwo.append(aClass.getSimpleName()+"|"+aMethod.getName());
							lineTwo.append(":Method Invocations Per Interval\"");
							lineTwo.append("\n");
							out.write(lineTwo.toString());
							
							out.write("\n");
						}
					}
		        }
		        
		        out.flush();
		        out.close();

			}
			catch (Exception e) {
				LOGGER.error("Error in process", e);
			}
		}
	}
}
