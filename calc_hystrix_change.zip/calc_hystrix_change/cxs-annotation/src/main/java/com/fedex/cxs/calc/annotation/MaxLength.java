package com.fedex.cxs.calc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation, to check for the length of strings or the value of numbers, that may be placed on a property (on the
 * getter method) inside a subclass of {@link BaseInputVO}. When a call is made to
 * {@link BaseInputVO#validate(String, com.fedex.cal.util.propertiesreader.ErrorPropertiesReader)}, either directly on
 * the class instance or somewhere up the object graph on an containing class instance, the value of the property will
 * be evaluated.<br>
 * <br>
 * <ul>
 * <li>If the value of the property is of type <code>String</code> and the length is greater than the supplied length, a
 * validation error will be added to the list of validation errors that the <code>validate()</code> method returns. Note
 * that an empty string is considered to be of length zero which will never generate an error.
 * <li>If the property is of type <code>int</code> or <code>double</code> and the value is more than the supplied
 * length, a validation error will be added to the list of validation errors that the <code>validate()</code> method
 * returns. Note that this means that value of zero or less will never generate an error.
 * <li>If the value of the property is of any other type, no error is generated.
 * <li>If the value of the property is of type <code>List</code> and an element of the list is of type
 * <code>String</code> with length greater than the supplied length, the error is generated.
 * <li>If the value of the list element is of any other type, no test is done and no error is generated.
 * <li>If any value of a <code>String</code> is <code>null</code>, NO error is generated.
 * </ul>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MaxLength
{
	int value();
}