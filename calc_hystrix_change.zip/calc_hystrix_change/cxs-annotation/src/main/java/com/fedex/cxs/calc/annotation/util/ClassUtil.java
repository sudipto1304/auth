package com.fedex.cxs.calc.annotation.util;

import java.io.File;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.jar.JarEntry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClassUtil {
	
	private static final String DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE = " does not appear to be a valid package";
	private static final char SLASH = '/';
	private static final char DOT = '.';
	private static final String JAR = "jar";
	private static final String CLASS = ".class";
	private static final HashMap<String, ArrayList<Class>> cachedClassList = new HashMap<String, ArrayList<Class>>();
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ClassUtil.class);
	private ClassUtil(){
		
	}
	public static List<Class> getClassesFromClasspath(String packageName)
			throws ClassNotFoundException {
		
		if (cachedClassList.containsKey(packageName)) {
			return cachedClassList.get(packageName);
		}
		else {
			ArrayList<Class> classes = new ArrayList<Class>();
	
			try {
				URL resource = Thread.currentThread().getContextClassLoader().getResource(packageName.replace(DOT, SLASH));
				LOGGER.info("Loading classes from URL resource:  " + resource);
				if (resource.getProtocol().equalsIgnoreCase(JAR)) {
					JarURLConnection url = (JarURLConnection) resource.openConnection();
					Enumeration<JarEntry> jarEntries = url.getJarFile().entries();
					classes = getClassesFromJar(jarEntries, packageName);
				} else {
					String directoryName = resource.getFile();
					directoryName = directoryName.replaceAll("%20", " ");
					File directory = new File(directoryName);
					classes = getClassesFromDirectory(directory, packageName);
				}
	
			} catch (NullPointerException x) {
				LOGGER.error(packageName + DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE, x);
				throw new ClassNotFoundException(packageName + DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE);
			} catch (IOException e) {
				LOGGER.error(packageName + DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE, e);
				throw new ClassNotFoundException(packageName + DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE);
			}
			cachedClassList.put(packageName, classes);
			return classes;
		}
	}

	public static ArrayList<Class> getClassesFromDirectory(File directory, 	String packageName) throws ClassNotFoundException {
		ArrayList<Class> classes = new ArrayList<Class>();
		if (directory.exists()) {
			// Get the list of the files contained in the package
			String[] files = directory.list();
			if (files != null) {
				for (int i = 0; i < files.length; i++) {
					// we are only interested in .class files
					if (files[i].endsWith(CLASS)) {
						// removes the .class extension
						String qualifiedClassName = packageName + '.' + files[i].substring(0, files[i].length() - 6);
						try {
							classes.add(Class.forName(qualifiedClassName));
						} catch (java.lang.ExceptionInInitializerError e) {
							LOGGER.error("Unable to initialize " + qualifiedClassName + ", check for static initializer issues", e);
						}
					} else {
						String newPackageName = files[i];
						if (packageName != null) {
							newPackageName = packageName + "." + files[i];
						}
						classes.addAll(getClassesFromDirectory(new File(directory.getPath() + "/" + files[i]), newPackageName));
					}
				}
			}
		} else {
			throw new ClassNotFoundException(packageName + DOES_NOT_APPEAR_TO_BE_A_VALID_PACKAGE);
		}
		return classes;
	}

	private static ArrayList<Class> getClassesFromJar(
			Enumeration<JarEntry> jarEntryList, String pckgname)
			throws ClassNotFoundException {
		ArrayList<Class> classes = new ArrayList<Class>();
		String pckgFolderStruct = pckgname.replace(DOT, SLASH);
		while (jarEntryList.hasMoreElements()) {
			JarEntry jarEntry = jarEntryList.nextElement();
			String className = jarEntry.getName();
			if (className.startsWith(pckgFolderStruct) && className.endsWith(CLASS)) {
				String fullClassName = className.substring(0, className.length() - 6);
				classes.add(Class.forName(fullClassName.replace(SLASH, DOT)));
			}
		}

		return classes;
	}
}
