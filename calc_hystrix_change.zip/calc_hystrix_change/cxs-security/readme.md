## ** **Latest Version 3.7.0-SNAPSHOT**


# Version 3.7.0-SNAPSHOT

## Release Note
* Change ``RequestorIdentity`` object
* ``getIdentity, setIdentity, getRawIdentity, setRawIdentity`` methods are deprecated
* Added ``ConsumerIdentity`` and ``ClientIdentity``
* Added new ``AuthenticationRealm`` as **CMAC**
* Please find alternatives for deprecated methods

## Alternatives


```java
getIdentity() ---> getConsumerIdentity().getIdentity();
setIdentity(String identity) ---> getConsumerIdentity().setIdentity(String identity);
getRawIdentity() ---> getConsumerIdentity().getRawIdentity();
setRawIdentity(String rawIdentity) ---> getConsumerIdentity().setRawIdentity(String rawIdentity);
```

## New ClientIdentity fields

```java
private String clientKey;
private String applicationId;
private String childKey;
private String childSecret;
```