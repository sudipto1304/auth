package com.fedex.cxs.calc.transformation.filters;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.GenericFilterBean;

import com.fedex.cxs.calc.transformation.util.HeaderConstants;
import com.fedex.cxs.calc.transformation.util.TransactionIdGenerator;
import com.fedex.cxs.calc.transformation.util.TransactionIdProvider;
import com.fedex.cxs.core.context.CXSContextHolder;

public class TransactionIdFilter extends GenericFilterBean {

	
	private static final Logger Log = LoggerFactory.getLogger(TransactionIdFilter.class);
	
	
	public static final String LOG4J_MDC_TRANSACTION_ID = "transactionId";
	
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {		

					
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String transactionIdFromRequest = httpRequest.getHeader(HeaderConstants.TRANSACTION_ID_HEADER);
		String customerTransactionId=httpRequest.getHeader(HeaderConstants.CUSTOMER_TRANSACTION_ID);
		if(null!=customerTransactionId) {
			Log.debug("CustomerTransactionID is present in request header--{}", customerTransactionId);
			CXSContextHolder.getContext().setCustomerTransactionID(customerTransactionId);
		}
		if (StringUtils.isEmpty(transactionIdFromRequest)) {
			// No transaction id from input. Create and set transaction id.
			/*
			 * Following statement is not working due to mismatch in WL request
			 * and Jersey request.TODO
			 * requestContext.getHeaders().add(TRANSACTION_ID_HEADER,
			 * uid.toString());
			 */
			TransactionIdGenerator.generateTransactionId();
			transactionIdFromRequest = TransactionIdProvider.get();
		} else {
			// transaction id from input. set transaction id to provider and
			// thread context of lo4j mdc.
			TransactionIdProvider.set(transactionIdFromRequest);
		}
		//FIXME LOG4J_MDC_TRANSACTION_ID
		MDC.put(LOG4J_MDC_TRANSACTION_ID, transactionIdFromRequest);
	
		
		chain.doFilter(request, response);
		TransactionIdProvider.destroy();
	}

}
